<?php $this->load->view("inc/head.php"); ?>
<?php $this->load->view("inc/header.php"); ?>
<?php $this->load->view("inc/left_sidebar.php"); ?>
<?php $this->load->view("inc/opciones.php"); ?>
<?php $this->load->view("inc/footer.php"); ?>
<?php $this->load->view("inc/scripts.php"); ?>