<?php
if (isset($_GET['nuevo'])) {
    ?>
    <!-- general form elements -->
    <div class="col-md-10">
        <div class="box box-primary" >
            <div class="box-header with-border">
                <h3 class="box-title">Registrar Eventos</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form method="POST" id="eventInsert">
                <div class="box-body">
                    <div class="form-group">
                        <label>Tema</label>
                        <input type="text" class="form-control" name="tema_evento" id="tema_evento" placeholder="Tema">
                    </div>
                    <div class="form-group">
                        <label>Lugar</label>
                        <input type="text" class="form-control" name="lugar_evento" id="lugar_evento" placeholder="Lugar">
                    </div>

                    <div class="box-body pad">
                        <label>Contenido</label>
                        <textarea class="textarea" name="contenido_evento" id="contenido_evento" placeholder="Digite algún texto aquí"
                                  style="width: 100%; height: 200px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;"></textarea>
                    </div>

                    <div class="form-group">
                        <label>Expositor</label>
                        <select name="cod_graduados" id="cod_graduados" class="form-control select2" style="width: 100%;"></select>
                    </div>

                    <div class="row">
                        <div class="col-md-6">

                            <div class="form-group">
                                <label>Fecha</label>
                                <div class="input-group date">
                                    <div class="input-group-addon">
                                        <i class="fa fa-calendar"></i>
                                    </div>
                                    <input type="text" class="form-control pull-right" name="fecha_evento" id="fecha_evento">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="bootstrap-timepicker">
                                <div class="form-group">
                                    <label>Hora</label>

                                    <div class="input-group">
                                        <input type="text" class="form-control timepicker" name="hora_evento" id="hora_evento">

                                        <div class="input-group-addon">
                                            <i class="fa fa-clock-o"></i>
                                        </div>
                                    </div>
                                    <!-- /.input group -->
                                </div>
                                <!-- /.form group -->
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.box-body -->

                <div class="box-footer">
                    <button type="submit" class="btn btn-primary"><i class="ion-calendar"></i> Agregar</button>
                </div>
            </form>
        </div>
    </div>

    <?php
}
?>

<?php
if (isset($_GET['lista'])) {
    ?>
    <!--<div class="row">
        <div class="col-xs-12">-->

    <div class="box" id="lista" style="display: block">
        <div class="box-header">
            <h3 class="box-title">Lista de Eventos</h3>
        </div>
        <!-- /.box-header -->
        <div class="box-body">
            <table id="example3" class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>Tema</th>
                        <th>Lugar</th>
                        <th>Fecha</th>
                        <th>Hora</th>
                        <th>Acciones</th>
                        <!--<th>Borrar</th>-->
                    </tr>
                </thead>
                <tbody>
                </tbody>
            </table>
        </div>
    </div>

    <div id="eventModal" class="modal fade">
        <div class="modal-dialog">
            <form method="post" id="eventForm">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span></button>
                        <h4 class="modal-title">Add User</h4>
                    </div>
                    <div class="modal-body">

                        <div class="box-body">
                            <div class="form-group">
                                <label>Tema</label>
                                <input type="text" class="form-control" name="tema_evento" id="tema_evento" placeholder="Tema"> <!---->
                            </div>
                            <div class="form-group">
                                <label>Lugar</label>
                                <input type="text" class="form-control" name="lugar_evento" id="lugar_evento" placeholder="Lugar"> <!---->
                            </div>
                            <div class="form-group">
                                <label>Fecha</label>

                                <div class="input-group date">
                                    <div class="input-group-addon">
                                        <i class="fa fa-calendar"></i>
                                    </div>
                                    <input type="text" class="form-control pull-right" name="fecha_evento" id="fecha_evento">
                                </div>
                            </div>
                            <div class="form-group">
                                <label>Hora</label>
                                <input type="text" class="form-control" name="hora_evento" id="hora_evento" placeholder="   Hora">
                            </div>
                            <div class="form-group">
                                <label>Asistentes</label>
                                <input type="text" class="form-control" name="asistidos_evento" id="asistidos_evento" placeholder="Asistentes"> <!---->
                            </div>
                        </div>
                        <!-- /.box-body -->

                    </div>
                    <div class="modal-footer">
                        <input type="hidden" name="cod_evento" id="cod_evento" />
                        <input type="submit" name="action" id="action" class="btn btn-success" value="Guardar" />
                        <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Cerrar</button>

                        <!--<button type="button" class="btn btn-primary">Save changes</button>-->
                    </div>
                </div>
                <!-- /.modal-content -->
            </form>
            <!-- /.form -->
        </div>
        <!-- /.modal-dialog -->
    </div>
    <!-- /.modal -->

    <!-----------------------------------------------------------Evento simple-------------------------------------------->
    <div class="box" id="asistentes" style="display: none">

        <div class="box-header">
            <h3 class="box-title">Evento</h3>
        </div>
        <!-- /.box-header -->
        <div class="box-body">
            <table id="example4" class="table table-bordered table-striped">

                <thead>
                    <tr>
                        <th>Tema</th>
                        <th>Lugar</th>
                        <th>Fecha</th>
                        <th>Hora</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                </tbody>
            </table>
            <br/>
        </div>
    </div>

    <div class="box" id="asistentesEvento" style="display: none">

        <div class="box-header">
            <h3 class="box-title">Asistentes</h3>
        </div>
        <div class="box-body">
            <table id="example5" class="table table-bordered table-striped">

                <thead>
                    <tr>
                        <th>Nombre</th>
                        <th>Apellido</th>
                        <th>Correo</th>
                        <th>Telefono</th>
                        <th>Cedula</th>
                    </tr>
                </thead>
                <tbody>
                </tbody>
            </table>
        </div>
        <div class="box-footer">
            <button type="button" name="regresarEvento" class="btn btn-primary"><i class="glyphicon glyphicon-arrow-left"></i> Regresar</button>
        </div>
    </div>


    <div id="asistentesModal" class="modal fade">
        <div class="modal-dialog">
            <form method="post" id="asistentesForm">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span></button>
                        <h4 class="modal-title">Agregar Asistentes</h4>
                    </div>
                    <div class="modal-body">

                        <div class="box-body">
                            <div class="form-group">
                                <label>Nombre</label>
                                <input type="text" class="form-control" name="nom1_graduados" id="nom1_graduados" placeholder="Nombre">
                            </div>
                            <div class="form-group">
                                <label>Apellido</label>
                                <input type="text" class="form-control" name="apep_graduados" id="apep_graduados" placeholder="Apellido">
                            </div>
                            <div class="form-group">
                                <label>Cedula</label>
                                <input type="text" class="form-control" name="ced_graduados" id="ced_graduados" placeholder="Cedula">
                            </div>
                            <div class="form-group">
                                <label>Telefono</label>
                                <input type="text" class="form-control" name="telefm_graduados" id="teleff_graduados" placeholder="Telefono">
                            </div>
                            <div class="form-group">
                                <label>Correo</label>
                                <input type="email" class="form-control" name="correo2_graduados" id="correo2_graduados" placeholder="Correo">
                            </div>
                        </div>
                        <!-- /.box-body -->
                    </div>
                    <div class="modal-footer">
                        <input type="hidden" name="cod_eventos" id="cod_eventos" />
                        <input type="submit" name="action" id="action" class="btn btn-success" value="Aceptar" />
                        <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Cerrar</button>

                        <!--<button type="button" class="btn btn-primary">Save changes</button>-->
                    </div>
                </div>
                <!-- /.modal-content -->
            </form>
            <!-- /.form -->
        </div>
        <!-- /.modal-dialog -->
    </div>
    <!-- /.modal -->


    <div id="eliminarEventoModal" class="modal fade">
        <div class="modal-dialog">
            <form method="post" id="eliminarEventoForm">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span></button>
                        <h4 class="modal-title">Terminar evento</h4>
                    </div>
                    <div class="modal-body">

                        <div class="box-body">
                            <div class="form-group">
                                <label>¿Está seguro de terminar este evento?</label>
                            </div>
                        </div>
                        <!-- /.box-body -->

                    </div>
                    <div class="modal-footer">
                        <input type="hidden" name="cod_evento" id="cod_evento" />
                        <button type="submit" name="action" id="action" class="btn btn-primary pull-left">Terminar</button>
                        <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>

                        <!--<button type="button" class="btn btn-primary">Save changes</button>-->
                    </div>
                </div>
                <!-- /.modal-content -->
            </form>
            <!-- /.form -->
        </div>
        <!-- /.modal-dialog -->
    </div>
    <!-- /.modal -->

    <?php
}
?>


<?php
