<?php
if (isset($_GET['nuevo'])) {
    ?>
    <!-- general form elements -->
    <div class="box box-primary" id="filtrosGraduados" style="display: block">
        <div class="box-header with-border">
            <h3 class="box-title">Filtros</h3>
        </div>
        <!-- /.box-header -->
        <!-- form start -->
        <form method="POST" id="listGraduadosCodPro">
            <div class="box-body">

                <div class="row">
                    <div class="col-md-6">

                        <div class="form-group">
                            <label>Cohorte</label>
                            <select name="cod_cohorte" id="cod_cohorte" class="form-control select2" style="width: 100%;"></select>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Programa</label>
                            <select name="cod_programa" id="cod_programa" class="form-control select2" style="width: 100%;"></select>
                        </div>
                    </div>
                </div>

            </div>
            <!-- /.box-body -->

            <div class="box-footer">
                <button type="submit" class="btn btn-primary"><i class="glyphicon glyphicon-search"></i> Buscar</button>
            </div>
        </form>
    </div>

    <div class="box" id="listaGraduados" style="display: none">
        <div class="box-header">
            <h3 class="box-title">Lista de Graduados</h3>
        </div>
        <!-- /.box-header -->
        <div class="box-body">
            <table id="example6" class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>Nombres</th>
                        <th>Apellidos</th>
                        <th>Correo</th>
                        <th>Telefono</th>
                        <th>Acciones</th>
                        <!--<th>Borrar</th>-->
                    </tr>
                </thead>
                <tbody>
                </tbody>
            </table>
        </div>
        <!-- /.box-body -->

    </div>

    <div id="empleadorModal" class="modal fade">
        <div class="modal-dialog">
            <form method="post" id="empleadorForm">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span></button>
                        <h4 class="modal-title">Agregar Empleador</h4>
                    </div>
                    <div class="modal-body">

                        <div class="box-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Nombre</label>
                                        <input type="text" class="form-control" name="nombre_empleador" id="nombre_empleador" placeholder="Nombre">
                                        <label>Apellido</label>
                                        <input type="text" class="form-control" name="apellido_empleador" id="apellido_empleador" placeholder="Apellido"
                                               pattern="[A-Za-z]{12}" title="Introduce únicamente texto">

                                        <label>Empresa</label>
                                        <input type="text" class="form-control" name="empresa_empleador" id="empresa_empleador" placeholder="Empresa">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Correo</label>
                                        <input type="email" class="form-control" name="correo_empleador" id="correo_empleador" placeholder="Correo">
                                        <label>Telefono</label>
                                        <input type="number" class="form-control" name="telefono_empleador" id="telefono_empleador" placeholder="Telefono">
                                        <label>Tipo empresa</label>
                                        <select name="cod_tipo" id="cod_tipo" class="form-control select2" style="width: 100%;"></select>
                                    </div>
                                </div>

                            </div>
                        </div>
                        <!-- /.box-body -->
                    </div>
                    <div class="modal-footer">
                        <input type="hidden" name="cod_graduados" id="cod_graduados" />
                        <input type="submit" name="action" id="action" class="btn btn-success" value="Aceptar" />
                        <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Cerrar</button>

                    </div>
                </div>
                <!-- /.modal-content -->
            </form>
            <!-- /.form -->
        </div>
        <!-- /.modal-dialog -->
    </div>
    <!-- /.modal -->

    <!------------------------------- Graduado con sus empleadores --------------------------------------------->
    <div class="box" id="graduadoFiltrado" style="display: none">

        <div class="box-header">
            <h3 class="box-title">Graduado</h3>
        </div>
        <div class="box-body">
            <table id="example7" class="table table-bordered table-striped">

                <thead>
                    <tr>
                        <th>Nombre</th>
                        <th>Apellido</th>
                        <th>Correo</th>
                        <th>Telefono</th>
                        <th>Cedula</th>
                    </tr>
                </thead>
                <tbody>
                </tbody>
            </table>
        </div>
    </div>
    <div class="box" id="empleadoresFiltrado" style="display: none">

        <div class="box-header">
            <h3 class="box-title">Empleadores</h3>
        </div>
        <div class="box-body">
            <table id="example8" class="table table-bordered table-striped">

                <thead>
                    <tr>
                        <th>Empresa</th>
                        <th>Representante</th>
                        <th>Correo</th>
                        <th>Telefono</th>
                        <th>Fecha registro</th>
                        <th>Tipo</th>
                    </tr>
                </thead>
                <tbody>
                </tbody>
            </table>
        </div>
        <div class="box-footer">
            <button type="button" name="regresarEmpleadores" class="btn btn-primary"><i class="glyphicon glyphicon-arrow-left"></i> Regresar</button>
        </div>
    </div>

    <?php
}
?>