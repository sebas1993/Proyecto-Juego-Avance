<?php
if (isset($_GET['nuevo'])) {
    ?>
    <!-- general form elements -->
    <div class="col-md-10">
        <div class="box box-primary" >
            <div class="box-header with-border">
                <h3 class="box-title">Registrar Cohorte</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form method="POST" id="cohorteInsert">
                <div class="box-body">
                    <div class="form-group">
                        <label>Número cohorte</label>
                        <select name="num_cohorte" id="num_cohorte" class="form-control select2" style="width: 100%;">
                            <option value="0">Seleccione un número de cohorte</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Año cohorte</label>
                        <input type="number" class="form-control" name="anio_cohorte" id="anio_cohorte" placeholder="Ingrese un Año">
                    </div>

                </div>
                <!-- /.box-body -->

                <div class="box-footer">
                    <button type="submit" class="btn btn-primary"><i class="ion-android-list"></i> Agregar</button>
                </div>
            </form>
        </div>
    </div>

    <?php
}
?>

<?php
if (isset($_GET['lista'])) {
    ?>
    <!--<div class="row">
        <div class="col-xs-12">-->

    <div class="box" id="lista">
        <div class="box-header">
            <h3 class="box-title">Lista de Cohortes</h3>
        </div>
        <!-- /.box-header -->
        <div class="box-body">
            <table id="example9" class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>Cohorte</th>
                        <th>Año</th>
                        <th>Número</th>
                        <th>Acciones</th>
                        <!--<th>Borrar</th>-->
                    </tr>
                </thead>
                <tbody>
                </tbody>
                <!--<tfoot>
                    <tr>
                        <th>Tema</th>
                        <th>Lugar</th>
                        <th>Asistentes</th>
                        <th>Fecha</th>
                        <th>Editar</th>
                        <th>Borrar</th>
                    </tr>
                </tfoot>-->
            </table>
        </div>
        <!-- /.box-body -->

    </div>

    <!-- /.box -->
    <!--   </div>-->
    <!-- /.col -->
    <!--   </div>-->
    <!-- /.row -->

    <div id="cohorteModal" class="modal fade">
        <div class="modal-dialog">
            <form method="post" id="cohorteForm">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span></button>
                        <h4 class="modal-title">Add User</h4>
                    </div>
                    <div class="modal-body">

                        <div class="box-body">
                            <div class="form-group">
                                <label>Número cohorte</label>
                                <select name="num_cohorte" id="num_cohorte" class="form-control select2" style="width: 100%;">
                                    <option value="0">Seleccione un número de cohorte</option>
                                    <option value="1">1</option>
                                    <option value="2">2</option>
                                </select>
                            </div>

                            <div class="form-group">
                                <label>Año cohorte</label>
                                <input type="number" class="form-control" name="anio_cohorte" id="anio_cohorte" placeholder="Año">
                            </div>
                        </div>
                        <!-- /.box-body -->
                    </div>
                    <div class="modal-footer">
                        <input type="hidden" name="cod_cohorte" id="cod_cohorte" />
                        <input type="submit" name="action" id="action" class="btn btn-success" value="Guardar" />
                        <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Cerrar</button>

                        <!--<button type="button" class="btn btn-primary">Save changes</button>-->
                    </div>
                </div>
                <!-- /.modal-content -->
            </form>
            <!-- /.form -->
        </div>
        <!-- /.modal-dialog -->
    </div>
    <!-- /.modal -->

    <div id="eliminarCohorteModal" class="modal fade">
        <div class="modal-dialog">
            <form method="post" id="eliminarCohorteForm">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span></button>
                        <h4 class="modal-title">Eliminar cohorte</h4>
                    </div>
                    <div class="modal-body">

                        <div class="box-body">
                            <div class="form-group">
                                <label>¿Está seguro de eliminar esta cohorte?</label>
                            </div>
                        </div>
                        <!-- /.box-body -->

                    </div>
                    <div class="modal-footer">
                        <input type="hidden" name="cod_cohorte" id="cod_cohorte" />
                        <button type="submit" name="action" id="action" class="btn btn-primary pull-left">Eliminar</button>
                        <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>

                        <!--<button type="button" class="btn btn-primary">Save changes</button>-->
                    </div>
                </div>
                <!-- /.modal-content -->
            </form>
            <!-- /.form -->
        </div>
        <!-- /.modal-dialog -->
    </div>
    <!-- /.modal -->
    <?php
}
?>

