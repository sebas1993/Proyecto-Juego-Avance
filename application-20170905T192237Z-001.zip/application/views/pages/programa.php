<?php
if (isset($_GET['nuevo'])) {
    ?>
    <!-- general form elements -->
    <div class="col-md-10">
        <div class="box box-primary" >
            <div class="box-header with-border">
                <h3 class="box-title">Registrar Programa</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form method="POST" id="programaInsert">
                <div class="box-body">
                    <div class="form-group">
                        <label>Programa</label>
                        <input type="text" class="form-control" name="nom_programa" id="nom_programa" placeholder="Ingrese un programa"
                               pattern="[A-Za-z]{40}" title="Introduce únicamente texto">
                    </div>
                </div>
                <!-- /.box-body -->

                <div class="box-footer">
                    <button type="submit" class="btn btn-primary"><i class="ion-android-list"></i> Agregar</button>

                </div>
            </form>
        </div>
    </div>

    <?php
}
?>

<?php
if (isset($_GET['lista'])) {
    ?>
    <!--<div class="row">
        <div class="col-xs-12">-->

    <div class="box" id="lista">
        <div class="box-header">
            <h3 class="box-title">Lista de Programas</h3>
        </div>
        <!-- /.box-header -->
        <div class="box-body">
            <table id="example10" class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>Programa</th>
                        <th>Acciones</th>
                        <!--<th>Borrar</th>-->
                    </tr>
                </thead>
                <tbody>
                </tbody>
                <!--<tfoot>
                    <tr>
                        <th>Tema</th>
                        <th>Lugar</th>
                        <th>Asistentes</th>
                        <th>Fecha</th>
                        <th>Editar</th>
                        <th>Borrar</th>
                    </tr>
                </tfoot>-->
            </table>
        </div>
        <!-- /.box-body -->

    </div>

    <!-- /.box -->
    <!--   </div>-->
    <!-- /.col -->
    <!--   </div>-->
    <!-- /.row -->

    <div id="programaModal" class="modal fade">
        <div class="modal-dialog">
            <form method="post" id="programaForm">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span></button>
                        <h4 class="modal-title">Add User</h4>
                    </div>
                    <div class="modal-body">

                        <div class="box-body">
                            <div class="form-group">
                                <label>Programa</label>
                                <input type="text" class="form-control" name="nom_programa" id="nom_programa" placeholder="programa"
                                       pattern="[A-Za-z]{40}" title="Introduce únicamente texto">
                            </div>
                        </div>
                        <!-- /.box-body -->
                    </div>
                    <div class="modal-footer">
                        <input type="hidden" name="cod_programa" id="cod_programa" />
                        <input type="submit" name="action" id="action" class="btn btn-success" value="Guardar" />
                        <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Cerrar</button>

                        <!--<button type="button" class="btn btn-primary">Save changes</button>-->
                    </div>
                </div>
                <!-- /.modal-content -->
            </form>
            <!-- /.form -->
        </div>
        <!-- /.modal-dialog -->
    </div>
    <!-- /.modal -->
    
    
    
    <div id="eliminarProgramaModal" class="modal fade">
        <div class="modal-dialog">
            <form method="post" id="eliminarProgramaForm">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span></button>
                        <h4 class="modal-title">Eliminar programa</h4>
                    </div>
                    <div class="modal-body">

                        <div class="box-body">
                            <div class="form-group">
                                <label>¿Está seguro de eliminar este programa?</label>
                            </div>
                        </div>
                        <!-- /.box-body -->

                    </div>
                    <div class="modal-footer">
                        <input type="hidden" name="cod_programa" id="cod_programa" />
                        <button type="submit" name="action" id="action" class="btn btn-primary pull-left">Eliminar</button>
                        <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>

                        <!--<button type="button" class="btn btn-primary">Save changes</button>-->
                    </div>
                </div>
                <!-- /.modal-content -->
            </form>
            <!-- /.form -->
        </div>
        <!-- /.modal-dialog -->
    </div>
    <!-- /.modal -->

    <?php
}
?>

