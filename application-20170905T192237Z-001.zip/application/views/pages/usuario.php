<?php
if (isset($_GET['nuevo'])) {
    ?>
    <!-- general form elements -->
    <div class="col-md-12">
        <div class="box box-primary" >
            <div class="box-header with-border">
                <h3 class="box-title">Registrar Graduados</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form method="POST" id="usuInsert">
                <div class="box-body">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label >Primer Nombre</label>
                                <input type="text" class="form-control" name="nom1_graduados" id="nom1_graduados" placeholder="Primer Nombre"> 
                                <label>Segundo Nombre</label>
                                <input type="text" class="form-control" name="nom2_graduados" id="nom2_graduados" placeholder="Segundo Nombre">
                                <label>Primer Apellido</label>
                                <input type="text" class="form-control" name="apep_graduados" id="apep_graduados" placeholder="Primer Apellido"
                                       pattern="[A-Za-z]{12}" title="Introduce únicamente texto">
                                <label>Segundo Apellido</label>
                                <input type="text" class="form-control" name="apem_graduados" id="apem_graduados" placeholder="Segundo Apellido"
                                       pattern="[A-Za-z]{12}" title="Introduce únicamente texto">

                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Telefono Convencional</label>
                                <input type="number" class="form-control" name="teleff_graduados" id="teleff_graduados" placeholder="Convencional">
                                <label>Correo Institucional</label>
                                <input type="email" class="form-control" name="correo1_graduados" id="correo1_graduados" placeholder="Institucional">
                                <label>Telefono Movil</label>
                                <input type="number" class="form-control" name="telefm_graduados" id="teleff_graduados" placeholder="Movil">
                                <label>Correo Personal</label>
                                <input type="email" class="form-control" name="correo2_graduados" id="correo1_graduados" placeholder="Personal">
                            </div>
                        </div>

                    </div>

                    <div class="form-group">
                        <label>Cedula</label>
                        <input type="number" class="form-control" name="ced_graduados" id="ced_graduados" placeholder="Cedula">
                    </div>

                    <!--<div class="form-group">    onchange="ShowSelected();" -->
                    <div class="form-group">
                        <label>Cohorte</label>
                        <select name="cod_cohorte" id="cod_cohorte" class="form-control select2" style="width: 100%;"></select>
                    </div>
                    <div class="form-group">
                        <label>Programa</label>
                        <select name="cod_programa" id="cod_programa" class="form-control select2" style="width: 100%;"></select>
                    </div>


                </div>
                <!-- /.box-body -->

                <div class="box-footer">
                    <button type="submit" class="btn btn-primary"><i class="ion-android-person-add"></i> Agregar</button>	
                </div>
            </form>
        </div>
    </div>

    <?php
}
?>

<?php
if (isset($_GET['lista'])) {
    ?>
    <!--<div class="row">
        <div class="col-xs-12">-->

    <div class="box">
        <div class="box-header">
            <h3 class="box-title">Lista de Graduados</h3>
        </div>
        <!-- /.box-header -->
        <div class="box-body">
            <table id="example2" class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>Nombres</th>
                        <th>Apellidos</th>
                        <th>Correo</th>
                        <th>Telefono</th>
                        <th>Acciones</th>
                        <!--<th>Borrar</th>-->
                    </tr>
                </thead>
                <tbody>
                </tbody>
                <!--<tfoot>
                    <tr>
                        <th>Nombres</th>
                        <th>Apellidos</th>
                        <th>Correo</th>
                        <th>Usuario</th>
                        <th>Editar</th>
                        <th>Borrar</th>
                    </tr>
                </tfoot>-->
            </table>
        </div>
        <!-- /.box-body -->
    </div>
    <!-- /.box -->
    <!--   </div>-->
    <!-- /.col -->
    <!--   </div>-->
    <!-- /.row -->

    <div id="userModal" class="modal fade">
        <div class="modal-dialog">
            <form method="post" id="userForm">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span></button>
                        <h4 class="modal-title">Add User</h4>
                    </div>
                    <div class="modal-body">
                        <div class="box-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Primer Nombre</label>
                                        <input type="text" class="form-control" name="nom1_graduados" id="nom1_graduados" placeholder="Primer Nombre">
                                        <label>Segundo Nombre</label>
                                        <input type="text" class="form-control" name="nom2_graduados" id="nom2_graduados" placeholder="Segundo Nombre">
                                        <label>Primer Apellido</label>
                                        <input type="text" class="form-control" name="apep_graduados" id="apep_graduados" placeholder="Primer Apellido">
                                        <label>Segundo Apellido</label>
                                        <input type="text" class="form-control" name="apem_graduados" id="apem_graduados" placeholder="Segundo Apellido">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Telefono Convencional</label>
                                        <input type="text" class="form-control" name="teleff_graduados" id="teleff_graduados" placeholder="Convencional">
                                        <label>Telefono Movil</label>
                                        <input type="text" class="form-control" name="telefm_graduados" id="telefm_graduados" placeholder="Movil">
                                        <label>Correo Personal</label>
                                        <input type="email" class="form-control" name="correo1_graduados" id="correo1_graduados" placeholder="Personal">
                                        <label>Cedula</label>
                                        <input type="text" class="form-control" name="ced_graduados" id="ced_graduados" placeholder="Cedula">
                                    </div>
                                </div>
                            </div>

                        </div>
                        <!-- /.box-body -->

                    </div>
                    <div class="modal-footer">
                        <input type="hidden" name="cod_graduados" id="cod_graduados" />
                        <input type="submit" name="action" id="action" class="btn btn-success" value="Aceptar" />
                        <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Cerrar</button>

                        <!--<button type="button" class="btn btn-primary">Save changes</button>-->
                    </div>
                </div>
                <!-- /.modal-content -->
            </form>
            <!-- /.form -->
        </div>
        <!-- /.modal-dialog -->
    </div>
    <!-- /.modal -->

    <?php
}
?>