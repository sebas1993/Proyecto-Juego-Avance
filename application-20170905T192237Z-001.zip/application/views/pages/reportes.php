<?php
if (isset($_GET['generar'])) {
    ?>
    <section class="content">
        <div class="col-md-30">

            <div class="container box">
                <h3 align="center">Reportes del Sistema</h3>
                <br />
                <div class="col-lg-3 col-xs-6">
                    <!-- small box -->
                    <div class="small-box bg-aqua">
                        <div class="inner">
                            <h3>1</h3>

                            <p>Reporte Asistentes a un Evento</p>
                            <p>Lista de estudiantes asistidos a un evento</p>
                        </div>
                        <div class="icon">
                            <i class="icon ion-briefcase"></i>
                        </div>
                        <a href="?mod=reportes&reporteAsistentes" class="small-box-footer">
                            Consultar <i class="fa fa-arrow-circle-right"></i>
                        </a>
                    </div>
                </div>
                <div class="col-lg-3 col-xs-6">
                    <!-- small box -->
                    <div class="small-box bg-yellow-gradient">
                        <div class="inner">
                            <h3>2</h3>

                            <p>Reporte Graduados - Programa</p>
                            <p>Lista los graduados de un programa especifico</p>
                        </div>
                        <div class="icon">
                            <i class="ion-person-stalker"></i>
                        </div>
                        <a href="?mod=reportes&reportePrograma" class="small-box-footer">
                            Consultar <i class="fa fa-arrow-circle-right"></i>
                        </a>
                    </div>
                </div>
                <div class="col-lg-3 col-xs-6">
                    <!-- small box -->
                    <div class="small-box bg-green-active">
                        <div class="inner">
                            <h3>3</h3>
                            <p>Reporte Graduados por Fecha</p>
                            <p>Lista los graduados de un rango de fechas especificas</p>
                        </div>
                        <div class="icon">
                            <i class="icon ion-android-map"></i>
                        </div>
                        <a href="?mod=reportes&reporteGraduados" class="small-box-footer">
                            Consultar <i class="fa fa-arrow-circle-right"></i>
                        </a>
                    </div>
                </div>
                <div class="col-lg-3 col-xs-6">
                    <!-- small box -->
                    <div class="small-box bg-maroon-gradient">
                        <div class="inner">
                            <h3>4</h3>

                            <p>Reporte Graduados - Cohorte</p>
                            <p>Lista los graduados de una cohorte especifica</p>
                        </div>
                        <div class="icon">
                            <i class="icon ion-ios-book-outline"></i>
                        </div>
                        <a href="?mod=reportes&reporteCohorte" class="small-box-footer">
                            Consultar <i class="fa fa-arrow-circle-right"></i>
                        </a>
                    </div>
                </div>
                <div class="col-lg-3 col-xs-6">
                    <!-- small box -->
                    <div class="small-box bg-light-blue-gradient">
                        <div class="inner">
                            <h3>5</h3>

                            <p>Reporte Tipos de Empresa por Graduado</p>
                            <p>Lista los graduados de un tipo de Empresa en un rango de fechas</p>
                        </div>
                        <div class="icon">
                            <i class="icon ion-ios-list-outline"></i>
                        </div>
                        <a href="?mod=reportes&reporteEmpresa" class="small-box-footer">
                            Consultar <i class="fa fa-arrow-circle-right"></i>
                        </a>
                    </div>
                </div>
                <div class="col-lg-3 col-xs-6">
                    <!-- small box -->
                    <div class="small-box bg-orange-active">
                        <div class="inner">
                            <h3>6</h3>
                            <p>Reporte Cohorte - Programa</p>
                            <p>Lista todos los graduados de una Cohorte y un programa</p>
                        </div>
                        <div class="icon">
                            <i class="icon ion-android-map"></i>
                        </div>
                        <a href="?mod=reportes&reporteCohortePrograma" class="small-box-footer">
                            Consultar <i class="fa fa-arrow-circle-right"></i>
                        </a>
                    </div>
                </div>
                <div class="col-lg-3 col-xs-6">
                    <!-- small box -->
                    <div class="small-box bg-purple-gradient">
                        <div class="inner">
                            <h3>7</h3>

                            <p>Reporte Seguimiento</p>
                            <p>Lista el seguimiento a un graduado en un intervalo de tiempo</p>
                        </div>
                        <div class="icon">
                            <i class="icon ion-document-text"></i>
                        </div>
                        <a href="?mod=reportes&reporteSeguimiento" class="small-box-footer">
                            Consultar <i class="fa fa-arrow-circle-right"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <?php
}
?>
<?php
/* * ******PANTALLAS PARA CADA REPORTE * */

if (isset($_GET['reporteAsistentes'])) {
    ?>
    <div class="col-md-30">
        <form method="post" action="">
            <div class="box box-primary" >
                <div class="box-header with-border">
                    <h3 align="center">Reporte de Asistentes por Evento</h3>
                </div>
                <div class="box-body">
                    <div class="form-group">
                        <label>Seleccione un Evento</label>
                        <?php
                        $varConsulta1 = &get_instance();
                        $varConsulta1->load->model('m_reportes');
                        $consultaResultado1 = $varConsulta1->m_reportes->obtenerTodosEventos();
                        $combobit = "";
                        foreach ($consultaResultado1 as $row) {
                            $combobit .=" <option value='" . $row['cod_evento'] . "'>" . $row['tema_evento'] . "</option>"; //concatenamos el los options para luego ser insertado en el HTML
                        }
                        ?>
                        <select name="cbxEvento" class="form-control select2" data-placeholder="Selecciones un Evento" style="width: 100%;">
                            <option name='' value=''>Seleccione una opcion</option>
                            <?php echo $combobit; ?>
                        </select>
                    </div>
                    <div class="box-footer">
                        <button type="submit" class="btn btn-primary"><i class="glyphicon glyphicon-search"></i> Buscar</button>
                    </div>
                </div>
            </div>
        </form>
        <?php
        if (isset($_POST['cbxEvento']) && $_POST['cbxEvento'] !== '') {
            $varCons = &get_instance();
            $varCons->load->model('m_reportes');
            $variable = $_POST['cbxEvento'];
            $this->session->consulta = $variable;
            $consultaResul = $varCons->m_reportes->obtenerInformacionEventos($variable);
            $consultaResulExpositor = $varCons->m_reportes->obtenerInformacionExpositor($variable);
            if (null !== $consultaResul) {
                echo ' <div class="box box-pane-right col-md-30 container" >
                        <div class="box-header with-border">
                            <h3 align="left">Datos del Evento</h3>
                    </div>
                    <br>
                    <table class="table table-bordered table-striped
                               ">
                            <tr>
                                <th>Cédula Expositor</th>
                                <th>Nombre Expositor</th>
                                <th>Correo Expositor</th>
                                <th>Tema Evento</th>
                                <th>Lugar Evento</th>
                                <th>Hora Evento</th>
                                <th>Fecha Evento</th>
                            </tr>';
                foreach ($consultaResul as $row) {
                    echo '
                                  <tr>
                                  <td>' . $consultaResulExpositor[0]->Cedula . '</td>
                                  <td>' . $consultaResulExpositor[0]->Nombre . ' ' . $consultaResulExpositor[0]->Apellido . '</td>
                                  <td>' . $consultaResulExpositor[0]->Correo . '</td>
                                  <td>' . $row->Tema . '</td>
                                  <td>' . $row->Lugar . '</td>
                                  <td>' . $row->Hora . '</td>
                                  <td>' . $row->Fecha . '</td>
                                  </tr>
                                  ';
                }
                echo '</table>';
            } else {
                echo '<div class="alert alert-success alert-dismissable">
                <i class="fa fa-check"></i>
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <b>Bien!</b> No existe Información que presentar 
              </div>';
            }
        }
        ?>
        <?php
        if (isset($_POST['cbxEvento']) && $_POST['cbxEvento'] !== '') {
            $varCons = &get_instance();
            $varCons->load->model('m_reportes');
            $variable = $_POST['cbxEvento'];
            $consultaResulX = $varCons->m_reportes->obtenerInformacionEventosAsistentes($variable);
            if (null !== $consultaResulX && sizeof($consultaResulX) > 0) {
                echo '    
                    <div class="box box-pane-right col-md-30 container" >
                        <div class="box-header with-border">
                            <h3 align="center">Lista de Asistentes</h3>
                    </div>
                    <br>
                        <table class="table table-bordered table-striped
                               ">
                            <tr>
                                <th>Cédula</th>
                                <th>Nombre</th>
                                <th>Apellido</th>
                                <th>Correo</th>
                                <th>Programa</th>

                            </tr>';
                foreach ($consultaResulX as $row) {
                    echo '
                                  <tr>
                                  <td>' . $row->Cedula . '</td>
                                  <td>' . $row->Nombre . '</td>
                                  <td>' . $row->Apellido . '</td>
                                  <td>' . $row->Correo . '</td>
                                  <td>' . $row->Programa . '</td>
                                  </tr>
                                  ';
                }
                echo '</table>';
                echo '<div align="center" class="box-header with-border">
                    <h4 align="center">EXPORTAR</h4>
                            <form method="post" action="">
                                <button type="submit" formaction="' . base_url() . 'c_reportes/descargarExcelAsistentes" class=" btn btn-default"/><i class="fa fa-file-excel-o" style="font-size:48px;color:green"></i><br>Excel</button>
                                <button type="submit" formaction="' . base_url() . 'c_reportes/descargarPdfAsistentes" class=" btn btn-default"/><i class="fa fa-file-pdf-o" style="font-size:48px;color:red"></i><br>PDF</button>
                            </form>
                        </div>';
            } else {
                echo '<div class="alert alert-warning alert-dismissable">
                <i class="glyphicon glyphicon-eye-open"></i>
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <b>Mensaje de Información: !</b> No existen Asistentes registrados para este evento.
              </div>
        </div>';
            }
        }
        ?>
        <br>
    </div>
    <?php
}
?>
<?php
if (isset($_GET['reportePrograma'])) {
    ?>
    <div class="col-md-30">
        <form method="post" action="">
            <div class="box box-primary" >
                <div class="box-header with-border">
                    <h3 align="center">Reporte por programa</h3>
                </div>
                <div class="box-body">
                    <div class="form-group">
                        <label>Seleccion de Fechas</label>
                        <div class="form-group">
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label>Fecha Inicial</label>
                                    <div class="input-group date">
                                        <div class="input-group-addon">
                                            <i class="fa fa-calendar"></i>
                                        </div>
                                        <input type="text" class="form-control pull-right" name="fechaI" id="fechaI">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label>Fecha Final</label>
                                    <div class="input-group date">
                                        <div class="input-group-addon">
                                            <i class="fa fa-calendar"></i>
                                        </div>
                                        <input type="text" class="form-control pull-right-container" name="fechaF" id="fechaF">
                                    </div>
                                </div>
                                <label>Seleccione un Programa</label>
                                <?php
                                $varConsulta2 = &get_instance();
                                $varConsulta2->load->model('m_reportes');
                                $consultaResultado2 = $varConsulta2->m_reportes->obtenerTodosProgramas();
                                $combobit = "";
                                foreach ($consultaResultado2 as $row) {
                                    $combobit .=" <option value='" . $row['cod_programa'] . "'>" . $row['nom_programa'] . "</option>"; //concatenamos el los options para luego ser insertado en el HTML
                                }
                                ?>
                                <select  name='hours' id="hours" class="form-control" data-placeholder="Selecciones un programa">
                                    <option name='' value=''>seleccione una opcion</option>
                                    <?php echo $combobit; ?>
                                </select>
                                <div class="box-footer">
                                    <button type="submit" class="btn btn-primary"><i class="glyphicon glyphicon-search"></i> Buscar</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
        <?php
        if (isset($_POST['hours']) && $_POST['hours'] !== '') {
            $varCons = &get_instance();
            $varCons->load->model('m_reportes');
            $variable = $_POST['hours'];
            $this->session->consulta = $variable;
            $variablei = date('Y-m-d', strtotime($_POST['fechaI']));
            $variablef = date('Y-m-d', strtotime($_POST['fechaF']));
            $this->session->consulta2 = $variablei;
            $this->session->consulta3 = $variablef;
            $consultaResul = $varCons->m_reportes->obtenerGraduadosPorPrograma($variable, $variablei, $variablef);
            if (null !== $consultaResul) {
                echo '    
                    <div class="box box-pane-right col-md-30 container" >
                        <div class="box-header with-border">
                            <h3 align="left">Tabla de Resultados</h3>
                    </div>
                    <br>
                        <table class="table table-bordered table-striped
                               ">
                            <tr>
                                <th>Nombre</th>
                                <th>Cedula</th>
                                <th>Apellido</th>
                                <th>Correo</th>
                                <th>Fecha</th>
                            </tr>';
                foreach ($consultaResul as $row) {
                    echo '
                                  <tr>
                                  <td>' . $row->Nombre . '</td>
                                  <td>' . $row->Cedula . '</td>
                                  <td>' . $row->Apellido . '</td>
                                  <td>' . $row->Correo . '</td>
                                  <td>' . $row->Fecha . '</td>
                                  </tr>
                                  ';
                }
                echo '</table>';
                echo '<div align="center" class="box-header with-border">
                    <h4 align="center">EXPORTAR</h4>
                            <form method="post" action="">
                                <button type="submit" formaction="' . base_url() . 'c_reportes/descargarExcelPrograma" class=" btn btn-default"/><i class="fa fa-file-excel-o" style="font-size:48px;color:green"></i><br>Excel</button>
                                <button type="submit" formaction="' . base_url() . 'c_reportes/descargarPdfPrograma" class=" btn btn-default"/><i class="fa fa-file-pdf-o" style="font-size:48px;color:red"></i><br>PDF</button>
                            </form>
                        </div>';
            } else {
                echo '<div class="alert alert-warning alert-dismissable">
                <i class="glyphicon glyphicon-eye-open"></i>
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <b>Mensaje de Información: !</b> No existen registros que presentar
              </div>
        </div>';
            }
        }
        ?>
        <br>
    </div>
    <?php
}
?>
<?php
if (isset($_GET['reporteGraduados'])) {
    ?>
    <div class="col-md-30">
        <form method="post" action="">
            <div class="box box-primary" >
                <div class="box-header with-border">
                    <h3 align="center">Reporte de Graduados</h3>
                </div>
                <div class="box-body">
                    <label>Seleccion de Fechas</label>
                    <div class="form-group">
                        <div class="col-md-3">
                            <div class="form-group">
                                <label>Fecha Inicial</label>
                                <div class="input-group date">
                                    <div class="input-group-addon">
                                        <i class="fa fa-calendar"></i>
                                    </div>
                                    <input type="text" class="form-control pull-right" name="fechaI" id="fechaI">
                                </div>
                            </div>
                            <div class="form-group">
                                <label>Fecha Final</label>
                                <div class="input-group date">
                                    <div class="input-group-addon">
                                        <i class="fa fa-calendar"></i>
                                    </div>
                                    <input type="text" class="form-control pull-right-container" name="fechaF" id="fechaF">
                                </div>
                            </div>
                            <div  >
                                <button type="submit" class="btn btn-primary"><i class="glyphicon glyphicon-search"></i> Buscar</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
        <?php
        if (isset($_POST['fechaI']) && $_POST['fechaI'] !== '') {
            $varCons = &get_instance();
            $varCons->load->model('m_reportes');
            $variablei = date('Y-m-d', strtotime($_POST['fechaI']));
            $variablef = date('Y-m-d', strtotime($_POST['fechaF']));
            $this->session->consulta = $variablei;
            $this->session->consulta2 = $variablef;
            $consultaResul = $varCons->m_reportes->obtenerGraduadosPorFecha($variablei, $variablef);
            if (null !== $consultaResul) {
                echo '
                    <div class="box box-pane-right col-md-30 container" >
                        <div class="box-header with-border">
                            <h3 align="left">Tabla de Resultados</h3>
                    </div>
                    <br>
                    <table class="table table-bordered table-striped
                               ">
                            <tr>
                                <th>Cedula</th>                                
                                <th>Nombre</th>
                                <th>Apellido</th>
                                <th>Correo</th>
                                <th>Programa</th>
                                <th>Cohorte</th>
                                <th>Fecha Registro</th>
                            </tr>';
                foreach ($consultaResul as $row) {
                    echo '
                                  <tr>' .
                    '<td>' . $row->cedula . '</td>
                                  <td>' . $row->nombre . '</td>
                                  <td>' . $row->apellido . '</td>
                                  <td>' . $row->correo . '</td>
                                  <td>' . $row->programa . '</td>
                                  <td>' . $row->cohorte . '</td>
                                  <td>' . $row->fecha . '</td>
                                  </tr>
                                  ';
                }
                echo '</table>';
                echo '<div align="center" class="box-header with-border">
                    <h4 align="center">EXPORTAR</h4>
                            <form method="post" action="">
                                <button type="submit" formaction="' . base_url() . 'c_reportes/descargarExcelGraduados"  class=" btn btn-default"/><i class="fa fa-file-excel-o" style="font-size:48px;color:green"></i><br>Excel</button>
                                <button type="submit" formaction="' . base_url() . 'c_reportes/descargarPdfGraduados" class=" btn btn-default"/><i class="fa fa-file-pdf-o" style="font-size:48px;color:red"></i><br>PDF</button>
                            </form>
                        </div>';
            } else {
                echo '<div class="alert alert-warning alert-dismissable">
                <i class="glyphicon glyphicon-eye-open"></i>
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <b>Mensaje de Información: !</b> No existen registros que presentar.
              </div>
        </div>';
            }
        }
        ?>
        <br>
    </div>
    <?php
}
?>
<?php
if (isset($_GET['reporteCohorte'])) {
    ?>
    <div class="col-md-30">
        <form method="post" action="">
            <div class="box box-primary" >
                <div class="box-header with-border">
                    <h3 align="center">Reporte por Cohorte</h3>
                </div>
                <div class="box-body">
                    <div class="form-group">
                        <label>Seleccion de Fechas</label>
                        <div class="form-group">
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label>Fecha Inicial</label>
                                    <div class="input-group date">
                                        <div class="input-group-addon">
                                            <i class="fa fa-calendar"></i>
                                        </div>
                                        <input type="text" class="form-control pull-right" name="fechaI" id="fechaI">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label>Fecha Final</label>
                                    <div class="input-group date">
                                        <div class="input-group-addon">
                                            <i class="fa fa-calendar"></i>
                                        </div>
                                        <input type="text" class="form-control pull-right-container" name="fechaF" id="fechaF">
                                    </div>
                                </div>
                                <label>Seleccione una Cohorte</label>
                                <?php
                                $varConsulta2 = &get_instance();
                                $varConsulta2->load->model('m_reportes');
                                $consultaResultado2 = $varConsulta2->m_reportes->obtenerTodosCohorte();
                                $combobit = "";
                                foreach ($consultaResultado2 as $row) {
                                    $combobit .=" <option value='" . $row['cod_cohorte'] . "'>" . $row['nom_cohorte'] . "</option>"; //concatenamos el los options para luego ser insertado en el HTML
                                }
                                ?>
                                <select  name='hours' id="hours" class="form-control" data-placeholder="Selecciones una cohorte">
                                    <option name='' value=''>seleccione una opcion</option>
                                    <?php echo $combobit; ?>
                                </select>
                                <div class="box-footer">
                                    <button type="submit" class="btn btn-primary"><i class="glyphicon glyphicon-search"></i> Buscar</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
        <?php
        if (isset($_POST['hours']) && $_POST['hours'] !== '') {
            $varCons = &get_instance();
            $varCons->load->model('m_reportes');
            $variable = $_POST['hours'];
            $variablei = date('Y-m-d', strtotime($_POST['fechaI']));
            $variablef = date('Y-m-d', strtotime($_POST['fechaF']));
            $this->session->consulta = $variable;
            $this->session->consulta2 = $variablei;
            $this->session->consulta3 = $variablef;
            $consultaResul = $varCons->m_reportes->obtenerGraduadosPorCohorte($variable, $variablei, $variablef);
            if (null !== $consultaResul) {
                echo '
                    <div class="box box-pane-right col-md-30 container" >
                        <div class="box-header with-border">
                            <h3 align="left">Tabla de Resultados</h3>
                    </div>
                    <br>
                    <table class="table table-bordered table-striped
                               ">
                            <tr>
                                <th>Cedula</th>                                
                                <th>Nombre</th>
                                <th>Apellido</th>
                                <th>Correo</th>
                                <th>Programa</th>
                                <th>Fecha Registro</th>
                            </tr>';
                foreach ($consultaResul as $row) {
                    echo '
                                  <tr>
                                  <td>' . $row->Cedula . '</td>
                                  <td>' . $row->Nombre . '</td>
                                  <td>' . $row->Apellido . '</td>
                                  <td>' . $row->Correo . '</td>
                                  <td>' . $row->Programa . '</td>
                                  <td>' . $row->Fecha . '</td>
                                  </tr>
                                  ';
                }
                echo '</table>';
                echo '<div align="center" class="box-header with-border">
                    <h4 align="center">EXPORTAR</h4>
                            <form method="post" action="">
                                <button type="submit" formaction="' . base_url() . 'c_reportes/descargarExcelCohorte"  class=" btn btn-default"/><i class="fa fa-file-excel-o" style="font-size:48px;color:green"></i><br>Excel</button>
                                <button type="submit" formaction="' . base_url() . 'c_reportes/descargarPdfCohorte" class=" btn btn-default"/><i class="fa fa-file-pdf-o" style="font-size:48px;color:red"></i><br>PDF</button>
                            </form>
                        </div>';
            } else {
                echo '<div class="alert alert-warning alert-dismissable">
                <i class="glyphicon glyphicon-eye-open"></i>
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <b>Mensaje de Información: !</b> No existen registros que presentar.
              </div>
        </div>';
            }
        }
        ?>
        <br>
    </div>
    <?php
}
?>
<?php
if (isset($_GET['reporteCohortePrograma'])) {
    ?>
    <div class="col-md-30">
        <form method="post" action="">
            <div class="box box-primary" >
                <div class="box-header with-border">
                    <h3 align="center">Reporte por Cohorte y Programa</h3>
                </div>
                <div class="box-body">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <div class="col-md-9">
                                    <div class="form-group">
                                        <label>Fecha Inicial</label>
                                        <div class="input-group date">
                                            <div class="input-group-addon">
                                                <i class="fa fa-calendar"></i>
                                            </div>
                                            <input type="text" class="form-control pull-right" name="fechaI" id="fechaI">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label>Fecha Final</label>
                                        <div class="input-group date">
                                            <div class="input-group-addon">
                                                <i class="fa fa-calendar"></i>
                                            </div>
                                            <input type="text" class="form-control pull-right-container" name="fechaF" id="fechaF">
                                        </div>
                                    </div>

                                </div>

                            </div>

                        </div>

                        <div class="col-md-6">
                            <div class="form-group">
                                <div class="col-md-9">
                                    <div class="form-group">

                                        <label>Seleccione una Cohorte</label>
                                        <?php
                                        $varConsulta2 = &get_instance();
                                        $varConsulta2->load->model('m_reportes');
                                        $consultaResultado2 = $varConsulta2->m_reportes->obtenerTodosCohorte();
                                        $combobit = "";
                                        foreach ($consultaResultado2 as $row) {
                                            $combobit .=" <option value='" . $row['cod_cohorte'] . "'>" . $row['nom_cohorte'] . "</option>"; //concatenamos el los options para luego ser insertado en el HTML
                                        }
                                        ?>
                                        <select  name='cbxCohorte' id="hours" class="form-control" data-placeholder="Selecciones una cohorte">
                                            <option name='' value=''>seleccione una opcion</option>
                                            <?php echo $combobit; ?>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label>Seleccione un Programa</label>
                                        <?php
                                        $varConsulta2 = &get_instance();
                                        $varConsulta2->load->model('m_reportes');
                                        $consultaResultado2 = $varConsulta2->m_reportes->obtenerTodosProgramas();
                                        $combobit = "";
                                        foreach ($consultaResultado2 as $row) {
                                            $combobit .=" <option value='" . $row['cod_programa'] . "'>" . $row['nom_programa'] . "</option>"; //concatenamos el los options para luego ser insertado en el HTML
                                        }
                                        ?>
                                        <select  name='cbxPrograma' id="hours" class="form-control" data-placeholder="Selecciones una cohorte">
                                            <option name='' value=''>seleccione una opcion</option>
                                            <?php echo $combobit; ?>
                                        </select>
                                    </div>

                                </div>
                            </div>
                        </div>

                    </div>

                    <div class="box-body" >
                        <button type="submit" class="btn btn-primary"><i class="glyphicon glyphicon-search"></i> Buscar</button>
                    </div>
                </div>
        </form>
        <?php
        if (isset($_POST['cbxCohorte']) && $_POST['cbxCohorte'] !== '') {
            $varCons = &get_instance();
            $varCons->load->model('m_reportes');
            $variableCohorte = $_POST['cbxCohorte'];
            $variablePrograma = $_POST['cbxPrograma'];
            $variablei = date('Y-m-d', strtotime($_POST['fechaI']));
            $variablef = date('Y-m-d', strtotime($_POST['fechaF']));
            $this->session->consulta = $variableCohorte;
            $this->session->consulta2 = $variablei;
            $this->session->consulta3 = $variablef;
            $this->session->consulta4 = $variablePrograma;
            $consultaResul = $varCons->m_reportes->obtenerGraduadosPorCohortePrograma($variableCohorte, $variablePrograma, $variablei, $variablef);
            if (null !== $consultaResul) {
                echo '
                    <div class="box box-pane-right col-md-30 container" >
                        <div class="box-header with-border">
                            <h3 align="left">Tabla de Resultados</h3>
                    </div>
                    <br>
                    <table class="table table-bordered table-striped
                               ">
                            <tr>
                                <th>Cedula</th>                                
                                <th>Nombre</th>
                                <th>Apellido</th>
                                <th>Correo</th>
                                <th>Telefono</th>
                                <th>Fecha Registro</th>
                            </tr>';
                foreach ($consultaResul as $row) {
                    echo '
                                  <tr>
                                  <td>' . $row->Cedula . '</td>
                                  <td>' . $row->Nombre . '</td>
                                  <td>' . $row->Apellido . '</td>
                                  <td>' . $row->Correo . '</td>
                                  <td>' . $row->Telefono . '</td>
                                  <td>' . $row->Fecha . '</td>
                                  </tr>
                                  ';
                }
                echo '</table>';
                echo '<div align="center" class="box-header with-border">
                    <h4 align="center">EXPORTAR</h4>
                            <form method="post" action="">
                                <button type="submit" formaction="' . base_url() . 'c_reportes/descargarExcelCohortePrograma"  class=" btn btn-default"/><i class="fa fa-file-excel-o" style="font-size:48px;color:green"></i><br>Excel</button>
                                <button type="submit" formaction="' . base_url() . 'c_reportes/descargarPdfCohortePrograma" class=" btn btn-default"/><i class="fa fa-file-pdf-o" style="font-size:48px;color:red"></i><br>PDF</button>
                            </form>
                        </div>';
            } else {
                echo '<div class="alert alert-warning alert-dismissable">
                <i class="glyphicon glyphicon-eye-open"></i>
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <b>Mensaje de Información: !</b> No existen registros que presentar.
              </div>
        </div>';
            }
        }
        ?>
        <br>
    </div>
    <?php
}
?>
<?php
if (isset($_GET['reporteEmpresa'])) {
    ?>
    <div class="col-md-30">
        <form method="post" action="">
            <div class="box box-primary" >
                <div class="box-header with-border">
                    <h3 align="center">Reporte por Empresa</h3>
                </div>
                <div class="box-body">
                    <div class="form-group">
                        <label>Seleccion de Fechas</label>
                        <div class="form-group">
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label>Fecha Inicial</label>
                                    <div class="input-group date">
                                        <div class="input-group-addon">
                                            <i class="fa fa-calendar"></i>
                                        </div>
                                        <input type="text" class="form-control pull-right" name="fechaI" id="fechaI">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label>Fecha Final</label>
                                    <div class="input-group date">
                                        <div class="input-group-addon">
                                            <i class="fa fa-calendar"></i>
                                        </div>
                                        <input type="text" class="form-control pull-right-container" name="fechaF" id="fechaF">
                                    </div>
                                </div>
                                <label>Seleccione un Tipo Empresa</label>
                                <?php
                                $varConsulta2 = &get_instance();
                                $varConsulta2->load->model('m_reportes');
                                $consultaResultado2 = $varConsulta2->m_reportes->obtenerTodosTipoEmpresa();
                                $combobit = "";
                                foreach ($consultaResultado2 as $row) {
                                    $combobit .=" <option value='" . $row['cod_tipo'] . "'>" . $row['nom_tipo'] . "</option>"; //concatenamos el los options para luego ser insertado en el HTML
                                }
                                ?>
                                <select  name='cbxEmpresa' id="hours" class="form-control" data-placeholder="Selecciones un tipo de Empresa">
                                    <option name='' value=''>seleccione una opcion</option>
                                    <?php echo $combobit; ?>
                                </select>
                                <div class="box-footer">
                                    <button type="submit" class="btn btn-primary"><i class="glyphicon glyphicon-search"></i> Buscar</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
        <?php
        if (isset($_POST['cbxEmpresa']) && $_POST['cbxEmpresa'] !== '') {
            $varCons = &get_instance();
            $varCons->load->model('m_reportes');
            $variable = $_POST['cbxEmpresa'];
            $variablei = date('Y-m-d', strtotime($_POST['fechaI']));
            $variablef = date('Y-m-d', strtotime($_POST['fechaF']));
            $this->session->consulta = $variable;
            $this->session->consulta2 = $variablei;
            $this->session->consulta3 = $variablef;
            $consultaResul = $varCons->m_reportes->obtenerGraduadosPorTipoEmpresa($variable, $variablei, $variablef);
            if (null !== $consultaResul) {
                echo '
                    <div class="box box-pane-right col-md-30 container" >
                        <div class="box-header with-border">
                            <h3 align="left">Tabla de Resultados</h3>
                    </div>
                    <br>
                    <table class="table table-bordered table-striped
                               ">
                            <tr>
                                <th>Nombre</th>
                                <th>Apellido</th>
                                <th>Correo</th>
                                <th>Empresa</th>
                                <th>Nombre</th>
                                <th>Apellido</th>
                                <th>Correo</th>
                            </tr>';
                foreach ($consultaResul as $row) {
                    echo '
                                  <tr>
                                  <td>' . $row->Nombre . '</td>
                                  <td>' . $row->Apellido . '</td>
                                  <td>' . $row->Correo . '</td>
                                  <td>' . $row->Empresa . '</td>
                                  <td>' . $row->Nombre_Empleador . '</td>
                                  <td>' . $row->Apellido_Empleador . '</td>
                                  <td>' . $row->Correo_Empleador . '</td>
                                  </tr>
                                  ';
                }
                echo '</table>';
                echo '<div align="center" class="box-header with-border">
                    <h4 align="center">EXPORTAR</h4>
                            <form method="post" action="">
                                <button type="submit" formaction="' . base_url() . 'c_reportes/descargarExcelEmpresa"  class=" btn btn-default"/><i class="fa fa-file-excel-o" style="font-size:48px;color:green"></i><br>Excel</button>
                                <button type="submit" formaction="' . base_url() . 'c_reportes/descargarPdfEmpresa" class=" btn btn-default"/><i class="fa fa-file-pdf-o" style="font-size:48px;color:red"></i><br>PDF</button>
                            </form>
                        </div>';
            } else {
                echo '<div class="alert alert-warning alert-dismissable">
                <i class="glyphicon glyphicon-eye-open"></i>
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <b>Mensaje de Información: !</b> No existen registros que presentar.
              </div>
        </div>';
            }
        }
        ?>
        <br>
    </div>
    <?php
}
?>
<?php
if (isset($_GET['reporteSeguimiento'])) {
    ?>
    <div class="col-md-30">
        <form method="post" action="">
            <div class="box box-primary" >
                <div class="box-header with-border">
                    <h3 align="center">Reporte Seguimiento Graduados</h3>
                </div>
                <div class="box-body">
                    <div class="form-group">
                        <div class="form-group">
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label>Fecha Inicial</label>
                                    <div class="input-group date">
                                        <div class="input-group-addon">
                                            <i class="fa fa-calendar"></i>
                                        </div>
                                        <input type="text" class="form-control pull-right" name="fechaI" id="fechaI">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label>Fecha Final</label>
                                    <div class="input-group date">
                                        <div class="input-group-addon">
                                            <i class="fa fa-calendar"></i>
                                        </div>
                                        <input type="text" class="form-control pull-right-container" name="fechaF" id="fechaF">
                                    </div>
                                </div>
                                <label>Seleccione un Graduado</label>
                                <?php
                                $varConsulta2 = &get_instance();
                                $varConsulta2->load->model('m_reportes');
                                $consultaResultado2 = $varConsulta2->m_reportes->obtenerTodosG();
                                $combobit = "";
                                foreach ($consultaResultado2 as $row) {
                                    $combobit .=" <option value='" . $row['cod_graduados'] . "'>" . $row['ced_graduados'] . '  - ' . $row['nom1_graduados'] . ' ' . $row['apep_graduados'] . "</option>"; //concatenamos el los options para luego ser insertado en el HTML
                                }
                                ?>
                                <select  name='hours' id="hours" class="form-control" data-placeholder="Selecciones un programa">
                                    <option name='' value=''>seleccione una opcion</option>
                                    <?php echo $combobit; ?>
                                </select>
                                <div class="box-footer">
                                    <button type="submit" class="btn btn-primary"><i class="glyphicon glyphicon-search"></i> Buscar</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </form>
    <?php
    if (isset($_POST['hours']) && $_POST['hours'] !== '') {
        $varCons = &get_instance();
        $varCons->load->model('m_reportes');
        $variable = $_POST['hours'];
        $variablei = date('Y-m-d', strtotime($_POST['fechaI']));
        $variablef = date('Y-m-d', strtotime($_POST['fechaF']));
        $this->session->consulta2 = $variablei;
        $this->session->consulta3 = $variablef;
        $this->session->consulta = $variable;
        $consultaResul = $varCons->m_reportes->obtenerGraduadosPorSeguimiento($variable, $variablei, $variablef);
        if (null !== $consultaResul) {
            echo '
                    <div class="box box-pane-right col-md-30 container" >
                        <div class="box-header with-border">
                            <h3 align="left">Seguimiento</h3>
                    </div>
                    <br>
                    <table class="table table-bordered table-striped
                               ">
                            <tr>
                                <th>Empresa</th>
                                <th>Nombre</th>
                                <th>Apellido</th>
                                <th>Telefono</th>
                                <th>Correo</th>
                                <th>Fecha Registro</th>
                            </tr>';
            foreach ($consultaResul as $row) {
                echo '
                                  <tr>
                                  <td>' . $row->Empresa . '</td>
                                  <td>' . $row->Nombre_Empleador . '</td>
                                  <td>' . $row->Apellido_Empleador . '</td>
                                  <td>' . $row->Telefono . '</td>
                                  <td>' . $row->Correo_Empleador . '</td>
                                  <td>' . $row->Fecha_Registro . '</td>
                                  </tr>
                                  ';
            }
            echo '</table>';
            echo '<div align="center" class="box-header with-border">
                    <h4 align="center">EXPORTAR</h4>
                            <form method="post" action="">
                                <button type="submit" formaction="' . base_url() . 'c_reportes/descargarExcelSeguimiento"  class=" btn btn-default"/><i class="fa fa-file-excel-o" style="font-size:48px;color:green"></i><br>Excel</button>
                                <button type="submit" formaction="' . base_url() . 'c_reportes/descargarPdfSeguimiento" class=" btn btn-default"/><i class="fa fa-file-pdf-o" style="font-size:48px;color:red"></i><br>PDF</button>
                            </form>
                        </div>';
        } else {
            echo '<div class="alert alert-warning alert-dismissable">
                <i class="glyphicon glyphicon-eye-open"></i>
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <b>Mensaje de Información: !</b> No existen registros que presentar.
              </div>
        </div>';
        }
    }
    ?>
    <br>
    </div>
    <?php
}
?>
        








