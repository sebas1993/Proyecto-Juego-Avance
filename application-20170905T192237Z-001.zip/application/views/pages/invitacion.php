<?php
if (isset($_GET['envio'])) {
    ?>
    <!-- general form elements -->
    <div class="box box-primary" id="filtrosGraduadosInvitacion" style="display: block">
        <div class="box-header with-border">
            <h3 align="center">Invitaciones a Curso</h3>
        </div>
        <div class="box-header with-border">
            <h3 class="box-title">Seleccion de Filtros</h3>
        </div>
        <!-- /.box-header -->
        <!-- form start -->
        <form method="POST" id="invitacion">
            <div class="box-body">

                <div class="row">
                    <div class="col-md-6">

                        <div class="form-group">
                            <label>Cohorte</label>
                            <select name="cod_cohorte" id="cod_cohorte" class="form-control select2" style="width: 100%;"></select>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Programa</label>
                            <select name="cod_programa" id="cod_programa" class="form-control select2" style="width: 100%;"></select>
                        </div>
                    </div>
                </div>

            </div>
            <!-- /.box-body -->

            <div class="box-footer">
                <button type="submit" class="btn btn-primary"><i class="glyphicon glyphicon-search"></i> Buscar</button>
            </div>
        </form>
    </div>

    <div class="box" id="listaGraduadosInvitacion" style="display: none">
        <div class="box-header">
            <h3 class="box-title">Evento</h3>
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <select name="cod_evento" id="cod_evento" class="form-control select2" style="width: 100%;"></select>
                    </div>

                </div>
                <div class="col-md-6">
                    <button type="button" name="escribirMensaje" class="btn btn-primary"><i class="glyphicon glyphicon-envelope"></i> Enviar a todos</button>
                </div>
            </div>

        </div>
        <div class="box-header">
            <h3 class="box-title">Lista de Graduados</h3>
        </div>
        <!-- /.box-header -->
        <div class="box-body">
            <table id="example6" class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>Nombres</th>
                        <th>Apellidos</th>
                        <th>Correo</th>
                        <th>Telefono</th>
                        <th>Acciones</th>
                        <!--<th>Borrar</th>-->
                    </tr>
                </thead>
                <tbody>
                </tbody>
            </table>
        </div>
        <!-- /.box-body -->

    </div>


    <div id="emailModal" class="modal fade">
        <div class="modal-dialog">
            <form method="post" id="emailForm">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span></button>
                        <h4 class="modal-title">Redactar mensaje</h4>
                    </div>
                    <div class="modal-body">

                        <div class="box-body">
                            <div class="box-body pad">
                                <label>Contenido</label>
                                <textarea class="textarea" name="contenido_evento" id="contenido_evento" placeholder="Escriba algún texto aquí"
                                          style="width: 100%; height: 200px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;"></textarea>
                            </div>
                        </div>
                        <!-- /.box-body -->
                    </div>
                    <div class="modal-footer">
                        <input type="hidden" name="cod_eventos" id="cod_eventos" />
                        <input type="hidden" name="cod_graduado" id="cod_graduado" />
                        <input type="hidden" name="tipo" id="tipo" />
                        <button type="submit" name="action" id="action" class="btn btn-primary"><i class="glyphicon glyphicon-envelope"></i> Enviar</button>
                        <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Cerrar</button>
                    </div>
                </div>
                <!-- /.modal-content -->
            </form>
            <!-- /.form -->
        </div>
        <!-- /.modal-dialog -->
    </div>
    <!-- /.modal -->


    <?php
}
?>