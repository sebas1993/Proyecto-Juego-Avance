


<!-- jQuery 2.2.3 -->
<script src="<?php echo base_url() . "assets/plugins/jQuery/jquery-2.2.3.min.js" ?>"></script>
<!-- jQuery UI 1.11.4 -->
<script src="https://code.jquery.com/ui/1.11.4/jquery-ui.min.js"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
    $.widget.bridge('uibutton', $.ui.button);</script>
<!-- Bootstrap 3.3.6 -->
<script src="<?php echo base_url() . "assets/bower_components/bootstrap/dist/js/bootstrap.min.js" ?>"></script>
<!-- Morris.js charts -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
<script src="<?php echo base_url() . "assets/plugins/morris/morris.min.js" ?>"></script>
<!-- Sparkline -->
<script src="<?php echo base_url() . "assets/plugins/sparkline/jquery.sparkline.min.js" ?>"></script>
<!-- jvectormap -->
<script src="<?php echo base_url() . "assets/plugins/jvectormap/jquery-jvectormap-1.2.2.min.js" ?>"></script>
<script src="<?php echo base_url() . "assets/plugins/jvectormap/jquery-jvectormap-world-mill-en.js" ?>"></script>
<!-- jQuery Knob Chart -->
<script src="<?php echo base_url() . "assets/plugins/knob/jquery.knob.js" ?>"></script>
<!-- daterangepicker -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.11.2/moment.min.js"></script>
<script src="<?php echo base_url() . "assets/plugins/daterangepicker/daterangepicker.js" ?>"></script>
<!-- datepicker -->
<script src="<?php echo base_url() . "assets/plugins/datepicker/bootstrap-datepicker.js" ?>"></script>
<!-- bootstrap time picker -->
<script src="<?php echo base_url() . "assets/plugins/timepicker/bootstrap-timepicker.min.js" ?>"></script>
<!-- Bootstrap WYSIHTML5 -->
<script src="<?php echo base_url() . "assets/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js" ?>"></script>
<!-- Slimscroll -->
<script src="<?php echo base_url() . "assets/plugins/slimScroll/jquery.slimscroll.min.js" ?>"></script>
<!-- FastClick -->
<script src="<?php echo base_url() . "assets/plugins/fastclick/fastclick.js" ?>"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url() . "assets/dist/js/app.min.js" ?>"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="<?php echo base_url() . "assets/dist/js/pages/dashboard.js" ?>"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo base_url() . "assets/dist/js/demo.js" ?>"></script>
<!-- DataTables -->
<script src="<?php echo base_url() . "assets/plugins/datatables/jquery.dataTables.js" ?>"></script>
<script src="<?php echo base_url() . "assets/plugins/datatables/dataTables.bootstrap.js" ?>"></script>



<script type="text/javascript" language="javascript">

    /*********/

    //Date picker
    $('#fecha_evento').datepicker({
        autoclose: true
    });
    $('#fechaI').datepicker({
        autoclose: true
    });
    $('#fechaF').datepicker({
        autoclose: true
    });




    $(function () {
        //Timepicker
        $(".timepicker").timepicker({
            showInputs: false
        });
    });
    var dataTable = $('#example1').DataTable({
        "processing": true,
        "serverSide": true,
        "order": [],
        "oLanguage": {
            "sSearch": "Buscar:",
            "sLengthMenu": "Mostrar _MENU_ Registros",
            "sInfo": "Mostrando _START_ a _END_ de entradas _TOTAL_",
            "sInfoEmpty": "Registros no encontrados",
            "sZeroRecords": "No hay registros disponibles",
            "sInfoFiltered": "(Filtrados de _MAX_ registros totales)",
            "oPaginate": {
                "sNext": "Siguiente",
                "sPrevious": "Anterior"
            }
        },
        "ajax": {
            "url": "<?php echo base_url() . 'c_administrador/listarAdministradores'; ?>",
            "type": "POST"
        },
        "columnDefs": [
            {
                "targets": [0, 3, 4],
                "orderable": false,
            },
        ],
    });
    $(document).on('submit', '#adminInsert', function (event) {
        event.preventDefault();
        var nom_admin = $('#nom_admin').val();
        var ape_admin = $('#ape_admin').val();
        var correo_admin = $('#correo_admin').val();
        var user_admin = $('#user_admin').val();
        var user_admin = $('#user_admin').val();
        $.ajax({
            url: "<?php echo base_url() . 'c_administrador/ingresoAdministrador' ?>",
            method: 'POST',
            data: new FormData(this),
            contentType: false,
            processData: false,
            success: function (data)
            {
                $('#adminInsert')[0].reset();
                $("#adminInsert").prepend(data);
            }
        });
    });
    $(document).on('submit', '#adminForm', function (event) {
        event.preventDefault();
        var nom_admin = $('#nom_admin').val();
        var ape_admin = $('#ape_admin').val();
        var correo_admin = $('#correo_admin').val();
        var user_admin = $('#user_admin').val();
        if (nom_admin != '' && ape_admin != '' && correo_admin != '' && user_admin != '')
        {
            $.ajax({
                url: "<?php echo base_url() . 'c_administrador/editarAdministrador' ?>",
                method: 'POST',
                data: new FormData(this),
                contentType: false,
                processData: false,
                success: function (data)
                {
                    //alert(data);
                    $('#adminForm')[0].reset();
                    $('#adminModal').modal('hide');
                    dataTable.ajax.reload();
                    $("#example1_wrapper").prepend(data);
                }
            });
        } else
        {

            alert("Debe llenar todos los campos");
        }
    });
    $(document).on('click', 'button[name=editar]', function () {
        var cod_admin = $(this).attr("id");
        $.ajax({
            url: "<?php echo base_url(); ?>c_administrador/obtenerAdministradorEditable",
            method: "POST",
            data: {cod_admin: cod_admin},
            dataType: "json",
            success: function (data)
            {
                $('#adminModal').modal('show');
                $('#nom_admin').val(data.nom_admin);
                $('#ape_admin').val(data.ape_admin);
                $('#correo_admin').val(data.correo_admin);
                $('#user_admin').val(data.user_admin);
                $('.modal-title').text("Editar administrador");
                $('#cod_admin').val(cod_admin);
            }
        })
    });


    $(document).on('submit', '#eliminarAdminForm', function (event) {
        event.preventDefault();
        var cod_admin = document.getElementById("cod_admin").value;

        $.ajax({
            url: "<?php echo base_url(); ?>c_administrador/eliminarAdministrador",
            method: "POST",
            data: {cod_admin: cod_admin},
            success: function (data)
            {
                dataTable.ajax.reload();
                $("#example1_wrapper").prepend(data);
                $('#eliminarAdminModal').modal('hide');

            }
        });
    });
    $(document).on('click', 'button[name=borrar]', function () {
        var cod_admin = $(this).attr("id");
        $('#eliminarAdminModal').modal('show');
        $('#cod_admin').val(cod_admin);
    });
    /*--------------------------------------------------GRADUADO--------------------------------------------------------*/

    var dataTable2 = $('#example2').DataTable({
        "processing": true,
        "serverSide": true,
        "order": [],
        "oLanguage": {
            "sSearch": "Buscar:",
            "sLengthMenu": "Mostrar _MENU_ Registros",
            "sInfo": "Mostrando _START_ a _END_ de entradas _TOTAL_",
            "sInfoEmpty": "Registros no encontrados",
            "sZeroRecords": "No hay registros disponibles",
            "sInfoFiltered": "(Filtrados de _MAX_ registros totales)",
            "oPaginate": {
                "sNext": "Siguiente",
                "sPrevious": "Anterior"
            }


        },
        "ajax": {
            "url": "<?php echo base_url() . 'c_graduado/listarUsuarios'; ?>",
            "type": "POST"
        },
        "columnDefs": [
            {
                "targets": [0, 3, 4],
                "orderable": false,
            },
        ],
    });
    $(document).on('submit', '#usuInsert', function (event) {
        event.preventDefault();
        var usuario = new FormData(this);
        var cod_cohorte = document.getElementById("cod_cohorte").value;
        var cod_programa = document.getElementById("cod_programa").value;
        usuario.append('cod_cohorte', cod_cohorte);
        usuario.append('cod_programa', cod_programa);
        $.ajax({
            url: "<?php echo base_url() . 'c_graduado/ingresoUsuario' ?>",
            method: 'POST',
            data: usuario,
            contentType: false,
            processData: false,
            success: function (data)
            {
                $('#usuInsert')[0].reset();
                $("#usuInsert").prepend(data);
            }
        });
    });
    $(document).on('submit', '#userForm', function (event) {
        event.preventDefault();
        var nom1_graduados = $('#nom1_graduados').val();
        var nom2_graduados = $('#nom2_graduados').val();
        var apep_graduados = $('#apep_graduados').val();
        var apem_graduados = $('#apem_graduados').val();
        var correo1_graduados = $('#correo1_graduados').val();
        var telefm_graduados = $('#telefm_graduados').val();
        var teleff_graduados = $('#teleff_graduados').val();
        var ced_graduados = $('#ced_graduados').val();
        if (nom1_graduados != '' && apep_graduados != '' && correo1_graduados != '' && telefm_graduados != '')
        {
            $.ajax({
                url: "<?php echo base_url() . 'c_graduado/editarUsuario' ?>",
                method: 'POST',
                data: new FormData(this),
                contentType: false,
                processData: false,
                success: function (data)
                {
                    //alert(data);
                    $('#userForm')[0].reset();
                    $('#userModal').modal('hide');
                    dataTable2.ajax.reload();
                    $("#example2_wrapper").prepend(data);
                }
            });
        } else
        {

            alert("Debe llenar todos los campos");
        }
    });
    $(document).on('click', 'button[name=editarGraduado]', function () {
        var cod_graduados = $(this).attr("id");
        $.ajax({
            url: "<?php echo base_url(); ?>c_graduado/obtenerUsuarioEditable",
            method: "POST",
            data: {cod_graduados: cod_graduados},
            dataType: "json",
            success: function (data)
            {
                $('#userModal').modal('show');
                $('#nom1_graduados').val(data.nom1_graduados);
                $('#nom2_graduados').val(data.nom2_graduados);
                $('#apep_graduados').val(data.apep_graduados);
                $('#apem_graduados').val(data.apem_graduados);
                $('#correo1_graduados').val(data.correo1_graduados);
                $('#telefm_graduados').val(data.telefm_graduados);
                $('#teleff_graduados').val(data.teleff_graduados);
                $('#ced_graduados').val(data.ced_graduados);
                $('.modal-title').text("Editar graduados");
                $('#cod_graduados').val(cod_graduados);
            }
        })
    });
    $(document).on('click', 'button[name=borrarGraduado]', function () {
        var cod_graduados = $(this).attr("id");
        if (confirm("¿Está seguro de eliminar este graduado?"))
        {
            $.ajax({
                url: "<?php echo base_url(); ?>c_graduado/eliminarUsuario",
                method: "POST",
                data: {cod_graduados: cod_graduados},
                success: function (data)
                {
                    dataTable2.ajax.reload();
                    $("#example2_wrapper").prepend(data);
                }
            });
        } else
        {
            return false;
        }
    });
    $(window).load(function () {
        $.getJSON("<?php echo base_url(); ?>c_cohorte/obtenerDatosCohorte", function (data) {
            $.each(data, function (id, valor) {
                $("#cod_cohorte").append('<option value="' + id + '">' + valor + '</option>');
            }); // close each()
        }); // close getJSON()
        $.getJSON("<?php echo base_url(); ?>c_programa/obtenerDatosPrograma", function (data) {
            $.each(data, function (id, valor) {
                $("#cod_programa").append('<option value="' + id + '">' + valor + '</option>');
            }); // close each()
        }); // close getJSON()
        $.getJSON("<?php echo base_url(); ?>c_tipoEmpresa/obtenerDatosTipoEmpresa", function (data) {
            $.each(data, function (id, valor) {
                $("#cod_tipo").append('<option value="' + id + '">' + valor + '</option>');
            }); // close each()
        }); // close getJSON()
        $.getJSON("<?php echo base_url(); ?>c_evento/obtenerDatosEvento", function (data) {
            $.each(data, function (id, valor) {
                $("#cod_evento").append('<option value="' + id + '">' + valor + '</option>');
            }); // close each()
        }); // close getJSON()
    });
    /*--------------------------------------------------Evento--------------------------------------------------------*/


    var dataTable3 = $('#example3').DataTable({
        "processing": true,
        "serverSide": true,
        "order": [],
        "oLanguage": {
            "sSearch": "Buscar:",
            "sLengthMenu": "Mostrar _MENU_ Registros",
            "sInfo": "Mostrando _START_ a _END_ de entradas _TOTAL_",
            "sInfoEmpty": "Registros no encontrados",
            "sZeroRecords": "No hay registros disponibles",
            "sInfoFiltered": "(Filtrados de _MAX_ registros totales)",
            "oPaginate": {
                "sNext": "Siguiente",
                "sPrevious": "Anterior"
            }
        },
        "ajax": {
            "url": "<?php echo base_url() . 'c_evento/listarEventos'; ?>",
            "type": "POST"
        },
        "columnDefs": [
            {
                "targets": [0, 3, 4],
                "orderable": false,
            },
        ],
    });
    $(document).on('submit', '#eventInsert', function (event) {
        event.preventDefault();
        var evento = new FormData(this);
        var cod_graduados = document.getElementById("cod_graduados").value;
        evento.append('cod_graduados', cod_graduados);
        $.ajax({
            url: "<?php echo base_url() . 'c_evento/ingresoEvento' ?>",
            method: 'POST',
            data: evento,
            contentType: false,
            processData: false,
            success: function (data)
            {
                $('#eventInsert')[0].reset();
                $("#eventInsert").prepend(data);
            }
        });
    });


    $(document).on('submit', '#emailForm', function (event) {
        event.preventDefault();
        var evento = new FormData(this);
        var cod_cohorte = document.getElementById("cod_cohorte").value;
        var cod_programa = document.getElementById("cod_programa").value;
        var cod_evento = document.getElementById("cod_evento").value;

        evento.append('cod_cohorte', cod_cohorte);
        evento.append('cod_programa', cod_programa);
        evento.append('cod_evento', cod_evento);

        $.ajax({
            url: "<?php echo base_url() . 'c_evento/editarContenidoEvento' ?>",
            method: 'POST',
            data: evento,
            contentType: false,
            processData: false,
            success: function (data)
            {
                //alert(data);
                $('#emailForm')[0].reset();
                $('#emailModal').modal('hide');
                //dataTable3.ajax.reload();
                alert(data);
            }
        });
    });
    $(document).on('submit', '#eventForm', function (event) {
        event.preventDefault();
        var tema_evento = $('#tema_evento').val();
        var lugar_evento = $('#lugar_evento').val();
        var fecha_evento = $('#fecha_evento').val();
        var hora_evento = $('#hora_evento').val();
        if (tema_evento != '' && lugar_evento != '' && fecha_evento != '' && hora_evento != '')
        {
            $.ajax({
                url: "<?php echo base_url() . 'c_evento/editarEvento' ?>",
                method: 'POST',
                data: new FormData(this),
                contentType: false,
                processData: false,
                success: function (data)
                {
                    //alert(data);
                    $('#eventForm')[0].reset();
                    $('#eventModal').modal('hide');
                    dataTable3.ajax.reload();
                    $("#example3_wrapper").prepend(data);
                }
            });
        } else
        {

            alert("Debe llenar todos los campos");
        }
    });
    $(document).on('click', 'button[name=editarEvento]', function () {
        var cod_evento = $(this).attr("id");

        $.ajax({
            url: "<?php echo base_url(); ?>c_evento/obtenerEventoEditable",
            method: "POST",
            data: {cod_evento: cod_evento},
            dataType: "json",
            success: function (data)
            {
                $('#eventModal').modal('show');
                $('#tema_evento').val(data.tema_evento);
                $('#lugar_evento').val(data.lugar_evento);
                $('#fecha_evento').val(data.fecha_evento);
                $('#hora_evento').val(data.hora_evento);
                $('.modal-title').text("Editar evento");
                $('#cod_evento').val(cod_evento);
            }
        })
    });

    var dataTable4;
    var dataTable5;

    $(document).on('click', 'button[name=borrarEvento]', function () {
        var cod_evento = $(this).attr("id");
        $('#eliminarEventoModal').modal('show');
        $('#cod_evento').val(cod_evento);
    });

    $(document).on('submit', '#eliminarEventoForm', function (event) {
        event.preventDefault();
        var cod_evento = document.getElementById("cod_evento").value;

        $.ajax({
            url: "<?php echo base_url(); ?>c_evento/eliminarEvento",
            method: "POST",
            data: {cod_evento: cod_evento},
            success: function (data)
            {
                dataTable3.ajax.reload();
                $("#example4_wrapper").prepend(data);
                $('#eliminarEventoModal').modal('hide');

            }
        });
    });


    var dataTable4;
    var dataTable5;
    var dataTable6;
    var dataTable7;
    var dataTable8;

    $(document).on('click', 'button[name=agregarAsistentes]', function () {
        var cod_eventos = $(this).attr("id");

        document.getElementById("lista").style.display = "none";
        document.getElementById("asistentes").style.display = "block";
        document.getElementById("asistentesEvento").style.display = "block";

        dataTable4 = $('#example4').DataTable({
            "processing": true,
            "serverSide": true,
            "destroy": true,
            "order": [],
            "bInfo": false,
            "paging": false,
            "ordering": false,
            "info": false,
            "searching": false,
            "ajax": {
                url: "<?php echo base_url() . 'c_evento/listarEventoSingle'; ?>",
                type: "POST",
                data: {cod_evento: cod_eventos}
            },
            "columnDefs": [
                {
                    "targets": [0, 3, 4],
                    "orderable": false
                }
            ]
        });

        dataTable5 = $('#example5').DataTable({
            "processing": true,
            "serverSide": true,
            "destroy": true,
            "order": [],
            "bInfo": false,
            "paging": false,
            "ordering": false,
            "info": false,
            "searching": false,
            "ajax": {
                url: "<?php echo base_url() . 'c_evento/listarAsistentes'; ?>",
                type: "POST",
                data: {cod_evento: cod_eventos}
            },
            "columnDefs": [
                {
                    "targets": [0, 3, 4],
                    "orderable": false
                }
            ]
        });

    });
    $(window).load(function () {
        $.getJSON("<?php echo base_url(); ?>c_graduado/obtenerDatosUsuario", function (data) {
            $.each(data, function (id, valor) {
                $("#cod_graduados").append('<option value="' + id + '">' + valor + '</option>');
            }); // close each()
        }); // close getJSON()

        $(".timepicker").timepicker({
            showInputs: false
        });
        $('[data-toggle="tooltip"]').tooltip();


    });

    $(document).on('click', 'button[name=agregarAsistentesUsuarios]', function () {
        var cod_evento = $(this).attr("id");
        $('#asistentesModal').appendTo("body").modal('show');
        $('#cod_eventos').val(cod_evento);
        //alert($('#cod_evento').val());
    });
    $(document).on('click', 'button[name=escribirMensaje]', function () {
        //var cod_evento = $(this).attr("id");
        var cod_evento = document.getElementById("cod_evento").value;
        var tipo = "grupal";
        //alert("Estoy en grupal");
        //$('#emailModal').appendTo("body").modal('show');
        $('#emailModal').modal('show');
        $('#cod_eventos').val(cod_evento);
        $('#tipo').val(tipo);
        //alert($('#tipo').val());
    });
    $(document).on('click', 'button[name=envioInvitacion]', function () {
        var cod_graduados = $(this).attr("id");
        var tipo = "individual";
        var cod_evento = document.getElementById("cod_evento").value;
        //alert("Estoy en individual");
        //$('#emailModal').appendTo("body").modal('show');
        $('#emailModal').modal('show');
        $('#cod_graduado').val(cod_graduados);
        $('#cod_eventos').val(cod_evento);
        $('#tipo').val(tipo);
        //alert($('#cod_graduados').val());
    });
    $(document).on('click', 'button[name=listarAsistentes]', function () {

        var cod_eventos = $(this).attr("id");

        document.getElementById("lista").style.display = "none";
        document.getElementById("asistentes").style.display = "block";
        document.getElementById("asistentesEvento").style.display = "block";

        dataTable4 = $('#example4').DataTable({
            "processing": true,
            "serverSide": true,
            "destroy": true,
            "order": [],
            "bInfo": false,
            "paging": false,
            "ordering": false,
            "info": false,
            "searching": false,
            "ajax": {
                url: "<?php echo base_url() . 'c_evento/listarEventoSingle'; ?>",
                type: "POST",
                data: {cod_evento: cod_eventos}
            },
            "columnDefs": [
                {
                    "targets": [0, 3, 4],
                    "orderable": false
                }
            ]
        });

        dataTable5 = $('#example5').DataTable({
            "processing": true,
            "serverSide": true,
            "destroy": true,
            "order": [],
            "bInfo": false,
            "paging": false,
            "ordering": false,
            "info": false,
            "searching": false,
            "ajax": {
                url: "<?php echo base_url() . 'c_evento/listarAsistentes'; ?>",
                type: "POST",
                data: {cod_evento: cod_eventos}
            },
            "columnDefs": [
                {
                    "targets": [0, 3, 4],
                    "orderable": false
                }
            ]
        });
    });

    $(document).on('submit', '#asistentesForm', function (event) {
        event.preventDefault();
        $.ajax({
            url: "<?php echo base_url() . 'c_evento/ingresoAsistentes' ?>",
            method: 'POST',
            data: new FormData(this),
            contentType: false,
            processData: false,
            success: function (data)
            {
                //alert(data);
                $('#asistentesForm')[0].reset();
                $('#asistentesModal').modal('hide');

                dataTable5.ajax.reload();
                $('#asistentesEvento')[0].reset();
                $("#example4_wrapper").prepend(data);
            }
        });
    });



    $(document).on('submit', '#listGraduadosCodPro', function (event) {
        event.preventDefault();
        var cod_cohorte = document.getElementById("cod_cohorte").value;
        var cod_programa = document.getElementById("cod_programa").value;
        var idForm = "listGraduadosCodPro";

        dataTable6 = $('#example6').DataTable({
            "processing": true,
            "serverSide": true,
            "order": [],
            "destroy": true,
            "bInfo": false,
            "paging": false,
            "ordering": false,
            "info": false,
            "searching": false,
            "ajax": {
                url: "<?php echo base_url() . 'c_empleador/listarGraduadosFiltrados'; ?>",
                type: "POST",
                data: {cod_cohorte: cod_cohorte,
                    cod_programa: cod_programa,
                    idForm: idForm}
            },
            "columnDefs": [
                {
                    "targets": [0, 3, 4],
                    "orderable": false
                }
            ]
        });
        document.getElementById("listaGraduados").style.display = "block";

    });

    $(document).on('click', 'button[name=agregarEmpleador]', function () {
        var cod_graduados = $(this).attr("id");
        $('#empleadorModal').appendTo("body").modal('show');
        $('#cod_graduados').val(cod_graduados);
    });

    $(document).on('click', 'button[name=listarEmpleadores]', function () {
        var cod_graduados = $(this).attr("id");

        document.getElementById("filtrosGraduados").style.display = "none";
        document.getElementById("listaGraduados").style.display = "none";
        document.getElementById("graduadoFiltrado").style.display = "block";
        document.getElementById("empleadoresFiltrado").style.display = "block";

        dataTable7 = $('#example7').DataTable({
            "processing": true,
            "serverSide": true,
            "order": [],
            "bInfo": false,
            "destroy": true,
            "paging": false,
            "ordering": false,
            "info": false,
            "searching": false,
            "ajax": {
                url: "<?php echo base_url() . 'c_empleador/listarGraduadoPorCodigo'; ?>",
                type: "POST",
                data: {cod_graduados: cod_graduados}
            },
            "columnDefs": [
                {
                    "targets": [0, 3, 4],
                    "orderable": false
                }
            ]
        });

        dataTable8 = $('#example8').DataTable({
            "processing": true,
            "serverSide": true,
            "order": [],
            "bInfo": false,
            "paging": false,
            "destroy": true,
            "ordering": false,
            "info": false,
            "searching": false,
            "ajax": {
                url: "<?php echo base_url() . 'c_empleador/listarEmpleadores'; ?>",
                type: "POST",
                data: {cod_graduados: cod_graduados}
            },
            "columnDefs": [
                {
                    "targets": [0, 3, 4],
                    "orderable": false
                }
            ]
        });
    });

    $(document).on('submit', '#invitacion', function (event) {
        event.preventDefault();
        var cod_cohorte = document.getElementById("cod_cohorte").value;
        var cod_programa = document.getElementById("cod_programa").value;
        var idForm = "invitacion";

        dataTable6 = $('#example6').DataTable({
            "processing": true,
            "serverSide": true,
            "order": [],
            "destroy": true,
            "bInfo": false,
            "paging": false,
            "ordering": false,
            "info": false,
            "searching": false,
            "ajax": {
                url: "<?php echo base_url() . 'c_empleador/listarGraduadosFiltrados'; ?>",
                type: "POST",
                data: {cod_cohorte: cod_cohorte,
                    cod_programa: cod_programa,
                    idForm: idForm}
            },
            "columnDefs": [
                {
                    "targets": [0, 3, 4],
                    "orderable": false
                }
            ]
        });
        document.getElementById("listaGraduadosInvitacion").style.display = "block";

    });




    $(document).on('submit', '#empleadorForm', function (event) {
        event.preventDefault();
        var empleador = new FormData(this);
        var cod_tipo = document.getElementById("cod_tipo").value;
        empleador.append('cod_tipo', cod_tipo);

        $.ajax({
            url: "<?php echo base_url() . 'c_empleador/ingresoEmpleador' ?>",
            method: 'POST',
            data: empleador,
            contentType: false,
            processData: false,
            success: function (data)
            {
                $('#empleadorForm')[0].reset();
                $('#empleadorModal').modal('hide');
                $("#example6_wrapper").prepend(data);
            }
        });
    });

    $(document).on('click', 'button[name=regresarEmpleadores]', function () {
        document.getElementById("filtrosGraduados").style.display = "block";
        document.getElementById("listaGraduados").style.display = "block";
        document.getElementById("graduadoFiltrado").style.display = "none";
        document.getElementById("empleadoresFiltrado").style.display = "none";
    });

    $(document).on('click', 'button[name=regresarEvento]', function () {
        //document.getElementById("filtrosGraduados").style.display = "block";
        document.getElementById("lista").style.display = "block";
        document.getElementById("asistentes").style.display = "none";
        document.getElementById("asistentesEvento").style.display = "none";
    });

    /*-------------------------------------------------------Cohorte-----------------------------------------------------------------------*/

    var dataTable9 = $('#example9').DataTable({
        "processing": true,
        "serverSide": true,
        "order": [],
        "oLanguage": {
            "sSearch": "Buscar:",
            "sLengthMenu": "Mostrar _MENU_ Registros",
            "sInfo": "Mostrando _START_ a _END_ de entradas _TOTAL_",
            "sInfoEmpty": "Registros no encontrados",
            "sZeroRecords": "No hay registros disponibles",
            "sInfoFiltered": "(Filtrados de _MAX_ registros totales)",
            "oPaginate": {
                "sNext": "Siguiente",
                "sPrevious": "Anterior"
            }


        },
        "ajax": {
            "url": "<?php echo base_url() . 'c_cohorte/listarCohortes'; ?>",
            "type": "POST"
        },
        "columnDefs": [
            {
                "targets": [3],
                "orderable": false,
            },
        ],
    });
    $(document).on('submit', '#cohorteInsert', function (event) {
        event.preventDefault();
        var cohorte = new FormData(this);
        var num_cohorte = document.getElementById("num_cohorte").value;
        //var cod_programa = document.getElementById("cod_programa").value;
        cohorte.append('num_cohorte', num_cohorte);
        $.ajax({
            url: "<?php echo base_url() . 'c_cohorte/ingresoCohorte' ?>",
            method: 'POST',
            data: cohorte,
            contentType: false,
            processData: false,
            success: function (data)
            {
                $('#cohorteInsert')[0].reset();
                $("#cohorteInsert").prepend(data);
            }
        });
    });
    $(document).on('submit', '#cohorteForm', function (event) {
        event.preventDefault();
        $.ajax({
            url: "<?php echo base_url() . 'c_cohorte/editarCohorte' ?>",
            method: 'POST',
            data: new FormData(this),
            contentType: false,
            processData: false,
            success: function (data)
            {
                //alert(data);
                $('#cohorteForm')[0].reset();
                $('#cohorteModal').modal('hide');
                dataTable9.ajax.reload();
                $("#example9_wrapper").prepend(data);
            }
        });
    });
    $(document).on('click', 'button[name=editarCohorte]', function () {
        var cod_cohorte = $(this).attr("id");
        $.ajax({
            url: "<?php echo base_url(); ?>c_cohorte/obtenerCohorteEditable",
            method: "POST",
            data: {cod_cohorte: cod_cohorte},
            dataType: "json",
            success: function (data)
            {
                $('#cohorteModal').modal('show');
                $('#num_cohorte').val(data.num_cohorte);
                $('#anio_cohorte').val(data.anio_cohorte);
                $('.modal-title').text("Editar cohorte");
                $('#cod_cohorte').val(cod_cohorte);
            }
        })
    });

    $(document).on('click', 'button[name=borrarCohorte]', function () {
        var cod_cohorte = $(this).attr("id");
        $('#eliminarCohorteModal').modal('show');
        $('#cod_cohorte').val(cod_cohorte);
    });

    $(document).on('submit', '#eliminarCohorteForm', function (event) {
        event.preventDefault();
        var cod_cohorte = document.getElementById("cod_cohorte").value;

        $.ajax({
            url: "<?php echo base_url(); ?>c_cohorte/eliminarCohorte",
            method: "POST",
            data: {cod_cohorte: cod_cohorte},
            success: function (data)
            {
                dataTable9.ajax.reload();
                $("#example9_wrapper").prepend(data);
                $('#eliminarCohorteModal').modal('hide');

            }
        });
    });

    /*-------------------------------------------------------Programa-----------------------------------------------------------------------*/

    var dataTable10 = $('#example10').DataTable({
        "processing": true,
        "serverSide": true,
        "order": [],
        "oLanguage": {
            "sSearch": "Buscar:",
            "sLengthMenu": "Mostrar _MENU_ Registros",
            "sInfo": "Mostrando _START_ a _END_ de entradas _TOTAL_",
            "sInfoEmpty": "Registros no encontrados",
            "sZeroRecords": "No hay registros disponibles",
            "sInfoFiltered": "(Filtrados de _MAX_ registros totales)",
            "oPaginate": {
                "sNext": "Siguiente",
                "sPrevious": "Anterior"
            }


        },
        "ajax": {
            "url": "<?php echo base_url() . 'c_programa/listarProgramas'; ?>",
            "type": "POST"
        },
        "columnDefs": [
            {
                "targets": [1],
                "orderable": false,
            },
        ],
    });
    $(document).on('submit', '#programaInsert', function (event) {
        event.preventDefault();
        var programa = new FormData(this);
        $.ajax({
            url: "<?php echo base_url() . 'c_programa/ingresoPrograma' ?>",
            method: 'POST',
            data: programa,
            contentType: false,
            processData: false,
            success: function (data)
            {
                $('#programaInsert')[0].reset();
                $("#programaInsert").prepend(data);
            }
        });
    });
    $(document).on('submit', '#programaForm', function (event) {
        event.preventDefault();
        $.ajax({
            url: "<?php echo base_url() . 'c_programa/editarPrograma' ?>",
            method: 'POST',
            data: new FormData(this),
            contentType: false,
            processData: false,
            success: function (data)
            {
                //alert(data);
                $('#programaForm')[0].reset();
                $('#programaModal').modal('hide');
                dataTable10.ajax.reload();
                $("#example10_wrapper").prepend(data);
            }
        });
    });
    $(document).on('click', 'button[name=editarPrograma]', function () {
        var cod_programa = $(this).attr("id");
        $.ajax({
            url: "<?php echo base_url(); ?>c_programa/obtenerProgramaEditable",
            method: "POST",
            data: {cod_programa: cod_programa},
            dataType: "json",
            success: function (data)
            {
                $('#programaModal').modal('show');
                $('#nom_programa').val(data.nom_programa);
                $('.modal-title').text("Editar programa");
                $('#cod_programa').val(cod_programa);
            }
        })
    });

    $(document).on('click', 'button[name=borrarPrograma]', function () {
        var cod_programa = $(this).attr("id");
        $('#eliminarProgramaModal').modal('show');
        $('#cod_programa').val(cod_programa);
    });

    $(document).on('submit', '#eliminarProgramaForm', function (event) {
        event.preventDefault();
        var cod_programa = document.getElementById("cod_programa").value;

        $.ajax({
            url: "<?php echo base_url(); ?>c_programa/eliminarPrograma",
            method: "POST",
            data: {cod_programa: cod_programa},
            success: function (data)
            {
                dataTable10.ajax.reload();
                $("#example10_wrapper").prepend(data);
                $('#eliminarProgramaModal').modal('hide');

            }
        });
    });



</script>
</body>
</html>

