<!-- Left side column. contains the logo and sidebar -->
<aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
        <!-- Sidebar user panel -->
        <div class="user-panel">
            <div class="pull-left image">
                <img src="<?php echo base_url() . "assets" ?>/dist/img/user2-160x160.jpg" class="img-circle" alt="User Image">
            </div>
            <div class="pull-left info">
                <p><?php echo $nom_admin, "&nbsp", $ape_admin ?></p>
            </div>
        </div>
        <ul class="sidebar-menu tree" data-widget="tree">
            <li class="header">NAVEGACION PRINCIPAL</li>
            <li class="active">
                <a href="c_general" data-ajax="false">
                    <i class="fa fa-home"></i> <span>Principal</span>
                </a>
            </li>


            <li class="treeview">
                <a href="#">
                    <i class="fa fa-group"></i>
                    <span>Graduados</span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu" style="display: none;">
                    <li><a href="?mod=usuario&nuevo"><i class="glyphicon glyphicon-floppy-open"></i> Registrar Graduados</a></li>
                    <li><a href="?mod=usuario&lista"><i class="glyphicon glyphicon-list"></i> Lista Graduados</a></li>
                </ul>
            </li>
            <li class="active treeview">
                <a href="#">
                    <i class="fa fa-check-square-o"></i> <span>Empleadores</span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu" style="display: none;">
                    <li class="active"><a href="?mod=empleador&nuevo"><i class="glyphicon glyphicon-pencil"></i> Registrar Empleadores</a></li>
                </ul>
            </li>
            <li class="active treeview">
                <a href="#">
                    <i class="fa fa-calendar"></i> <span>Eventos</span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu" style="display: none;">
                    <li class="active"><a href="?mod=evento&nuevo"><i class="fa fa-calendar-plus-o"></i> Registrar Eventos</a></li>
                    <li class="active"><a href="?mod=evento&lista"><i class="glyphicon glyphicon-list"></i> Registrar Asistentes</a></li>
                </ul>
            </li>
            <li class="active treeview">
                <a href="#">
                    <i class="fa fa-calendar"></i> <span>Invitaciones</span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu" style="display: none;">
                    <li class="active"><a href="?mod=invitacion&envio"><i class="fa fa-envelope"></i> Envio Invitaciones</a></li>
                   
                </ul>
            </li>
            <li class="active treeview">
                <a href="#">
                    <i class="fa fa-file"></i> <span>Reportes</span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu" style="display: none;">
                    <li class="active"><a href="?mod=reportes&generar"><i class="glyphicon glyphicon-pencil"></i> Generar Reportes</a></li>

                </ul>
            </li>
            <li class="active treeview">
                <a href="#">
                    <i class="glyphicon glyphicon-hdd"></i> <span>Mantenedores</span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu" style="display: none;">
                    <li class="active"><a href="?mod=cohorte&nuevo"><i class="glyphicon glyphicon-pencil"></i> Registrar Cohorte</a></li>
                    <li><a href="?mod=cohorte&lista"><i class="glyphicon glyphicon-list"></i> Lista De Cohortes</a></li>
                    <li class="active"><a href="?mod=programa&nuevo"><i class="glyphicon glyphicon-pencil"></i> Registrar Programa</a></li>
                    <li><a href="?mod=programa&lista"><i class="glyphicon glyphicon-list"></i> Lista De Programas</a></li>
                </ul>
            </li>
            <li class="active treeview">
                <a href="#">
                    <i class="fa fa-gears"></i> <span>Administracion</span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu" style="display: none;">
                    <li class="active"><a href="?mod=administrador&nuevo"><i class="glyphicon glyphicon-user"></i> Registrar Administrador</a></li>
                    <li><a href="?mod=administrador&lista"><i class="glyphicon glyphicon-list"></i> Lista De Administradores</a></li>
                </ul>
            </li>

        </ul>
    </section>
    <!-- /.sidebar -->
</aside>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->

    <!-- Main content -->
    <section class="content">
        <!-- Small boxes (Stat box) -->
