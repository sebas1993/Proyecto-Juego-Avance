<!DOCTYPE html>
<html class="lockscreen">
    <head>
        <!-- Bootstrap 3.3.6 -->
        <link rel="stylesheet" href="<?php echo base_url() . "/assets/bootstrap/css/bootstrap.min.css" ?>" type="text/css">
        <!-- Font Awesome -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
        <!-- Ionicons -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
        <!-- Theme style -->
        <link rel="stylesheet" href="<?php echo base_url() . "/assets/dist/css/AdminLTE.css" ?>" type="text/css">
        <!-- iCheck -->
        <link rel="stylesheet" href="<?php echo base_url() . "/assets/plugins/iCheck/square/blue.css" ?>" type="text/css">
    </head>
    <body class="lockscreen">
        <div class="login-box">
            <div style="text-align: center;" class="login-logo">Sistema de Seguimiento a Graduados</div>
            <!-- /.login-logo -->



            <div class="login-box-body">
                <form action="" method="POST">
                    <p class="login-box-msg">Inicie sesión para comenzar</p>
                    <div class="form-group has-feedback">
                        <input type="text" name="user" id="user" class="form-control" placeholder="User">
                        <span class="glyphicon glyphicon-user form-control-feedback"></span>
                    </div>
                    <div class="form-group has-feedback">
                        <input type="password" name="password" id="password" class="form-control" placeholder="Password">
                        <span class="glyphicon glyphicon-lock form-control-feedback"></span>
                    </div>
                    <div class="row">
                        <div class="col-xs-8">
                            <!--<div class="checkbox icheck">
                                <label>
                                    <input type="checkbox"> Remember Me
                                </label>
                            </div>-->
                        </div>
                        <!-- /.col -->
                        <div class="col-xs-4">
                            <button type="submit" class="btn btn-primary btn-block btn-flat">Entrar</button>
                        </div>
                        <!-- /.col -->
                    </div>
                    <!--
              <div class="social-auth-links text-center">
                  <p>- OR -</p>
                  <a href="#" class="btn btn-block btn-social btn-facebook btn-flat"><i class="fa fa-facebook"></i> Sign in using
                      Facebook</a>
                  <a href="#" class="btn btn-block btn-social btn-google btn-flat"><i class="fa fa-google-plus"></i> Sign in using
                      Google+</a>
              </div>
                    <!-- /.social-auth-links -->

                    <!--<a href="#">I forgot my password</a><br>
                    <a href="<?php echo base_url() . "assets/pages/register.html" ?>" class="text-center">Register a new membership</a>-->
                </form>
            </div>

            <!-- /.login-box-body -->
        </div>
        <!-- /.login-box -->

        <!-- jQuery 2.2.3 -->
        <script src="<?php echo base_url() . "/assets/plugins/jQuery/jquery-2.2.3.min.js" ?>"></script>
        <!-- Bootstrap 3.3.6 -->
        <script src="<?php echo base_url() . "/assets/bootstrap/js/bootstrap.min.js" ?>"></script>
        <!-- iCheck -->
        <script src="<?php echo base_url() . "/assets/plugins/iCheck/icheck.min.js" ?>"></script>
        <script>
            $(function () {
                $('input').iCheck({
                    checkboxClass: 'icheckbox_square-blue',
                    radioClass: 'iradio_square-blue',
                    increaseArea: '20%' // optional
                });
            });
        </script>
    </body>
</html>