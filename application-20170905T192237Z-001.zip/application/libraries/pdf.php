<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');
// Incluimos el archivo fpdf

include_once APPPATH . 'libraries\third_party\fpdf\fpdf.php';

//Extendemos la clase Pdf de la clase fpdf para que herede todas sus variables y funciones
class Pdf extends FPDF {

    public function __construct() {
        parent::__construct();
    }

    // El encabezado del PDF
    public function Header() {
        $this->Image(APPPATH . '\imagenes\logo-puce.jpg', 60, 8, 85);
        //$this->MultiCell(190,40, $this->Image('imagenes\logo.jpg', $this->GetX()+40, $this->GetY()+3, 100) ,0,"C");
        // $this->Image('imagenes\logo.jpg',10,72,150);
        $this->SetFont('Arial', 'B', 12);
        $this->Ln(25);
        $this->Cell(70);
        $this->Cell(55, 10, 'REPORTES SISTEMA SGI', 0, 0, 'C');
        $this->Ln(9);
        $this->SetFont('Arial', 'B', 11);
        $this->Cell(120);
        $this->Cell(70, 10, 'Responsable: ' . $_SESSION['nom_admin'].' '.$_SESSION['ape_admin'], 0, 0, 'R');
        $this->Ln(5);
        $startDate = date('Y-m-d');
        $this->Cell(120);
        $this->Cell(70, 10, 'Fecha de Ingreso: ' . $startDate, 0, 0, 'R');
        $this->Ln(15);
    }

    // El pie del pdf
    public function Footer() {
        $this->SetY(-15);
        $this->SetFont('Arial', 'I', 8);
        $this->Cell(0, 10, 'Page ' . $this->PageNo() . '/{nb}', 0, 0, 'C');
    }

}
