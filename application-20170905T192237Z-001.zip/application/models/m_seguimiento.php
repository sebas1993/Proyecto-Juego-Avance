<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class M_seguimiento extends CI_Model {
    
    public function __construct() {
        parent::__construct();
    }
    
    var $table = "seguimiento";
    var $select_column = array("cod_empleador", "fechai_seguimiento");
    var $order_column = array(null, "cod_empleador");
    
    public function ingresoSeguimiento($param) {

        $this->db->insert($this->table, $param);
        return $this->db->insert_id();
    }
    
    function ejecutarConsulta($where) {

        $this->db->select($this->select_column);
        $this->db->from($this->table);
        //$this->db->where("estado_evento", $this->estado);
        $this->db->where($where);
        /*if (isset($_POST["search"]["value"])) {
            $this->db->like("cod_graduados", $_POST["search"]["value"]);
            $this->db->or_like("cod_asistencia", $_POST["search"]["value"]);
        }*/
        if (isset($_POST["order"])) {
            $this->db->order_by($this->order_column[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        } else {
            $this->db->order_by('cod_empleador', 'DESC');
        }
    }
    
    function crearTabla($where) {
        $this->ejecutarConsulta($where);
        /* if ($_POST["length"] != -1) {
          $this->db->limit($_POST['length'], $_POST['start']);
          } */
        $this->db->where($where);
        $query = $this->db->get();
        return $query->result();
    }
    
    function obtenerTodosDatos($where) {
        $this->db->select("*");
        $this->db->from($this->table);
        $this->db->where($where);       //no es necesario pero dejar
        return $this->db->count_all_results();
    }

    function obtenerDatosFiltrados($where) {
        $this->ejecutarConsulta($where);
        $this->db->where($where);       //obtiene los administradores con estado activo
        $query = $this->db->get();
        return $query->num_rows();
    }
}
