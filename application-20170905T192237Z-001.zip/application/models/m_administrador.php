<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class M_administrador extends CI_Model {

    var $table = "administrador";
    var $select_column = array("cod_admin", "nom_admin", "ape_admin", "correo_admin", "user_admin");
    var $order_column = array(null, "nom_admin", "ape_admin", null, null);
    var $estado = "H";
    var $estadoEliminado = "E";

    public function __construct() {
        parent::__construct();
    }

    public function ingresoAdministrador($param) {

        $this->db->insert($this->table, $param);
    }

    function ejecutarConsulta() {
        
        $this->db->select($this->select_column);
        $this->db->from($this->table);
        $this->db->where("estado_admin",$this->estado);
        if (isset($_POST["search"]["value"])) {
            $this->db->like("nom_admin", $_POST["search"]["value"]);
            $this->db->or_like("ape_admin", $_POST["search"]["value"]);
        }
        if (isset($_POST["order"])) {
            $this->db->order_by($this->order_column[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        } else {
            $this->db->order_by('cod_admin', 'DESC');
        }
    }

    function crearTabla() {
        $this->ejecutarConsulta();
        if ($_POST["length"] != -1) {
            $this->db->limit($_POST['length'], $_POST['start']);
        }
        $this->db->where("estado_admin",$this->estado);
        $query = $this->db->get();
        return $query->result();
    }

    function obtenerDatosFiltrados() {
        $this->ejecutarConsulta();
        $this->db->where("estado_admin",$this->estado);       //obtiene los administradores con estado activo
        $query = $this->db->get();
        return $query->num_rows();
    }

    function obtenerTodosDatos() {
        $this->db->select("*");
        $this->db->from($this->table);
        $this->db->where("estado_admin",$this->estado);       //no es necesario pero dejar
        return $this->db->count_all_results();
    }

    function obtenerAdministradorEditable($cod_admin) {//traer usuario
        $this->db->where("cod_admin", $cod_admin);
        $query = $this->db->get('administrador');
        return $query->result();
    }

    function editarAdministrador($cod_admin, $data) {
        $this->db->where("cod_admin", $cod_admin);
        $this->db->update("administrador", $data);
    }

//    function eliminarAdministrador($cod_admin) {
//        $this->db->where("cod_admin", $cod_admin);
//        $this->db->delete("administrador");
//    }
    function eliminarAdministrador($cod_admin, $data) {
        $this->db->where("cod_admin", $cod_admin);
        $this->db->update("administrador", $data);
    }
}
