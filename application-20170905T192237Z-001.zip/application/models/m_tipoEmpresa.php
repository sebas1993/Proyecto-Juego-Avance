<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class M_tipoEmpresa extends CI_Model {

    public function __construct() {
        parent::__construct();
    }

    var $table = "tiposempresa";
    var $columnas_tipoEmpresa = array("cod_tipo", "nom_tipo");
    var $columnas_nomTipo = array("nom_tipo");

    function obtenerDatosTipoEmpresa() {
        $this->db->select($this->columnas_tipoEmpresa);
        $this->db->from($this->table);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result();
            //return $query->num_rows();
        }
        return FALSE;
    }
    function obtenerTipoEmpresa($where) {
        $this->db->select($this->columnas_tipoEmpresa);
        $this->db->from($this->table);
        $this->db->where($where);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result();
            //return $query->num_rows();
        }
        return FALSE;
    }

}


