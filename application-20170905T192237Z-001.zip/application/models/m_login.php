<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class M_login extends CI_Model {

    public function __construct() {
        parent::__construct();
    }

    public function login($user, $password) {
        $this->db->where('user_admin', $user);
        $this->db->where('passw_admin', $password);
        $q = $this->db->get('administrador');
        if ($q->num_rows() > 0) {
            return $q->row();
        } 
    }

}
