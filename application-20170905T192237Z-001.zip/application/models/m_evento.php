<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class M_evento extends CI_Model {

    var $table = "evento";
    var $select_column = array("cod_evento","tema_evento", "lugar_evento", "fecha_evento", "hora_evento");
    var $order_column = array(null, "tema_evento", "lugar_evento", null,null);
    var $estado = "H";
    var $estadoEliminado = "E";

    public function __construct() {
        parent::__construct();
    }
    
    function obtenerDatosEvento() {
        $this->db->select($this->select_column);
        $this->db->from($this->table);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result();
            //return $query->num_rows();
        }
        return FALSE;
    }

    public function ingresoEvento($param) {

        $this->db->insert($this->table, $param);
        return $this->db->insert_id();
    }

    function ejecutarConsulta($where) {

        $this->db->select($this->select_column);
        $this->db->from($this->table);
        //$this->db->where("estado_evento", $this->estado);
        $this->db->where($where);
        if (isset($_POST["search"]["value"])) {
            $this->db->like("tema_evento", $_POST["search"]["value"]);
            $this->db->or_like("lugar_evento", $_POST["search"]["value"]);
        }
        if (isset($_POST["order"])) {
            $this->db->order_by($this->order_column[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        } else {
            $this->db->order_by('cod_evento', 'DESC');
        }
    }

    function crearTabla($where) {
        $this->ejecutarConsulta($where);
        if ($_POST["length"] != -1) {
            $this->db->limit($_POST['length'], $_POST['start']);
        }
        //$this->db->where("estado_evento", $this->estado);
        $this->db->where($where);
        $query = $this->db->get();
        return $query->result();
    }

    function obtenerDatosFiltrados($where) {
        $this->ejecutarConsulta($where);
        $this->db->where($where);       //obtiene los administradores con estado activo
        $query = $this->db->get();
        return $query->num_rows();
    }

    function obtenerTodosDatos($where) {
        $this->db->select("*");
        $this->db->from($this->table);
        $this->db->where($where);       //no es necesario pero dejar
        return $this->db->count_all_results();
    }

    function obtenerEventoEditable($cod_evento) {//traer usuario
        $this->db->where("cod_evento", $cod_evento);
        $query = $this->db->get($this->table);
        return $query->result();
    }

    function editarEvento($cod_evento, $data) {
        $this->db->where("cod_evento", $cod_evento);
        $this->db->update($this->table, $data);
    }

    function eliminarEvento($cod_evento, $data) {
        $this->db->where("cod_evento", $cod_evento);
        $this->db->update($this->table, $data);
    }

}
