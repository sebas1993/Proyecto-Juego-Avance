<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class M_programa extends CI_Model {

    public function __construct() {
        parent::__construct();
    }

    var $table = "programa";
    var $columnas_programa = array("cod_programa", "nom_programa");
    var $order_column = array(null, "nom_programa");

    function obtenerDatosPrograma() {
        $this->db->select($this->columnas_programa);
        $this->db->from($this->table);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result();
            //return $query->num_rows();
        }
        return FALSE;
    }
    
    public function ingresoPrograma($param) {
        $this->db->insert($this->table, $param);
        return $this->db->insert_id();
    }

    function ejecutarConsulta($where) {

        $this->db->select($this->columnas_programa);
        $this->db->from($this->table);
        $this->db->where($where);
        /*if (isset($_POST["search"]["value"])) {
            $this->db->like("num_programa", $_POST["search"]["value"]);
            $this->db->or_like("anio_programa", $_POST["search"]["value"]);
        }*/
        if (isset($_POST["order"])) {
            $this->db->order_by($this->order_column[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        } else {
            $this->db->order_by('cod_programa', 'DESC');
        }
    }

    function crearTabla($where) {
        $this->ejecutarConsulta($where);
        if ($_POST["length"] != -1) {
            $this->db->limit($_POST['length'], $_POST['start']);
        }
        $this->db->where($where);
        $query = $this->db->get();
        return $query->result();
    }

    function obtenerDatosFiltrados($where) {
        $this->ejecutarConsulta($where);
        $this->db->where($where);       //obtiene los administradores con estado activo
        $query = $this->db->get();
        return $query->num_rows();
    }

    function obtenerTodosDatos($where) {
        $this->db->select("*");
        $this->db->from($this->table);
        $this->db->where($where);       //no es necesario pero dejar
        return $this->db->count_all_results();
    }

    function obtenerProgramaEditable($cod_programa) {//traer usuario
        $this->db->where("cod_programa", $cod_programa);
        $query = $this->db->get($this->table);
        return $query->result();
    }

    function editarPrograma($cod_programa, $data) {
        $this->db->where("cod_programa", $cod_programa);
        $this->db->update($this->table, $data);
    }

    function eliminarPrograma($cod_programa, $data) {
        $this->db->where("cod_programa", $cod_programa);
        $this->db->update($this->table, $data);
    }

}