<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class M_graduado extends CI_Model {

    public function __construct() {
        parent::__construct();
    }

    var $table = "graduados";
    var $select_column = array("cod_graduados", "nom1_graduados", "apep_graduados", "correo2_graduados", "telefm_graduados", "ced_graduados");
    var $order_column = array(null, "nom1_graduados", "apep_graduados", null, null);
    var $columnasCombo = array("cod_graduados","nom1_graduados", "apep_graduados");
    var $estado = "G";
    var $estadoEliminado = "E";

    public function ingresoUsuario($param) {
        $this->db->insert($this->table, $param);
        return $this->db->insert_id();
    }

    function ejecutarConsulta($where) {

        $this->db->select($this->select_column);
        $this->db->from($this->table);
        $this->db->where($where);
        if (isset($_POST["search"]["value"])) {
            $this->db->like("nom1_graduados", $_POST["search"]["value"]);
            $this->db->or_like("apep_graduados", $_POST["search"]["value"]);
        }
        if (isset($_POST["order"])) {
            $this->db->order_by($this->order_column[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        } else {
            $this->db->order_by('cod_graduados', 'DESC');
        }
    }

    function crearTabla($where) {
        $this->ejecutarConsulta($where);
        /*if ($_POST["length"] != -1) {
            $this->db->limit($_POST['length'], $_POST['start']);
        }*/
        $this->db->where($where);
        $query = $this->db->get();
        return $query->result();
    }

    function obtenerDatosFiltrados($where) {
        $this->ejecutarConsulta($where);
        $this->db->where($where);       //obtiene los administradores con estado activo
        $query = $this->db->get();
        return $query->num_rows();
    }

    function obtenerTodosDatos($where) {
        $this->db->select("*");
        $this->db->from($this->table);
        $this->db->where($where);       //no es necesario pero dejar
        return $this->db->count_all_results();
    }

    function obtenerUsuarioEditable($cod_graduados) {//traer usuario
        $this->db->where("cod_graduados", $cod_graduados);
        $query = $this->db->get($this->table);
        return $query->result();
    }

    function editarUsuario($cod_graduados, $data) {
        $this->db->where("cod_graduados", $cod_graduados);
        $this->db->update($this->table, $data);
    }


    function eliminarUsuario($cod_graduados, $data) {
        $this->db->where("cod_graduados", $cod_graduados);
        $this->db->update($this->table, $data);
    }
    
    function obtenerDatosUsuario() {
        $this->db->select($this->columnasCombo);
        $this->db->from($this->table);
        $this->db->where("estado_graduados", $this->estado);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result();
        }
        return FALSE;
    }

}
