<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class C_administrador extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('m_administrador');
    }
    function ingresoAdministrador() {
        $data = array();
        //$nacho = 'nom_admin';
        $data['nom_admin'] = strtoupper($_POST['nom_admin']);
        $data['ape_admin'] = strtoupper($_POST['ape_admin']);
        $data['correo_admin'] = strtoupper($_POST['correo_admin']);
        $data['user_admin'] = $_POST['user_admin'];
        $data['passw_admin'] = md5($_POST['passw_admin']);
        $data['estado_admin'] = "H";

        $this->m_administrador->ingresoAdministrador($data);
        echo '<div class="alert alert-success alert-dismissable">
                <i class="fa fa-check"></i>
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <b>Bien!</b> El administrador ha sido ingresado correctamente... 
              </div>';
    }

    function listarAdministradores() {
        $fetch_data = $this->m_administrador->crearTabla();
        $data = array();
        foreach ($fetch_data as $row) {
            $sub_array = array();
            $sub_array[] = $row->nom_admin;
            $sub_array[] = $row->ape_admin;
            $sub_array[] = $row->correo_admin;
            $sub_array[] = $row->user_admin;
            $sub_array[] = '<div class="btn-group">
                                <button type="button" name="editar" id="' . $row->cod_admin . '" class="btn btn-default"><i class="fa fa fa-edit"></i></button>
                                <button type="button" name="borrar" id="' . $row->cod_admin . '" class="btn btn-default"><i class="fa fa-close"></i></button>
                            </div>';
            $data[] = $sub_array;
        }
        $output = array(
            "draw" => intval($_POST["draw"]),
            "recordsTotal" => $this->m_administrador->obtenerTodosDatos(),
            "recordsFiltered" => $this->m_administrador->obtenerDatosFiltrados(),
            "data" => $data
        );
        echo json_encode($output);
    }

    function obtenerAdministradorEditable() {
        $output = array();
        $data = $this->m_administrador->obtenerAdministradorEditable($_POST['cod_admin']);
        foreach ($data as $row) {
            $output['nom_admin'] = $row->nom_admin;
            $output['ape_admin'] = $row->ape_admin;
            $output['correo_admin'] = $row->correo_admin;
            $output['user_admin'] = $row->user_admin;
        }
        echo json_encode($output);
    }

    function editarAdministrador() {
        $updated_data = array(
            'nom_admin' => $this->input->post('nom_admin'),
            'ape_admin' => $this->input->post('ape_admin'),
            'correo_admin' => $this->input->post('correo_admin'),
            'user_admin' => $this->input->post('user_admin'),
        );

        $this->m_administrador->editarAdministrador($this->input->post("cod_admin"), $updated_data);
        echo '<div class="alert alert-success alert-dismissable">
                <i class="fa fa-check"></i>
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <b>Bien!</b> El administrador ha sido editado correctamente... 
              </div>';
    }

    function eliminarAdministrador() {
        
        $updated_data = array(
            'estado_admin' => 'E'
        );
        
        $this->m_administrador->eliminarAdministrador($_POST["cod_admin"], $updated_data);
        echo '<div class="alert alert-success alert-dismissable">
                <i class="fa fa-check"></i>
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <b>Bien!</b> El administrador ha sido eliminado correctamente... 
              </div>';
    }
}
