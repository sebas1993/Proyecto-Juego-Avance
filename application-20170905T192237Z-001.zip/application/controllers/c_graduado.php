<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class C_graduado extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('m_graduado');
    }

    function ingresoUsuario() {
        $data = array();
        //$nacho = 'nom1_graduados';
        $data['nom1_graduados'] = strtoupper($_POST['nom1_graduados']);
        $data['nom2_graduados'] = strtoupper($_POST['nom2_graduados']);
        $data['apep_graduados'] = strtoupper($_POST['apep_graduados']);
        $data['apem_graduados'] = strtoupper($_POST['apem_graduados']);
        $data['teleff_graduados'] = strtoupper($_POST['teleff_graduados']);
        $data['telefm_graduados'] = strtoupper($_POST['telefm_graduados']);
        $data['correo1_graduados'] = $_POST['correo1_graduados'];
        $data['correo2_graduados'] = $_POST['correo2_graduados'];
        $data['ced_graduados'] = strtoupper($_POST['ced_graduados']);
        $data['cod_programa'] = strtoupper($_POST['cod_programa']);
        $data['cod_cohorte'] = strtoupper($_POST['cod_cohorte']);
        $data['cod_admin'] = $this->session->userdata('cod_admin');
        $data['estado_graduados'] = "G";
        $data['fechai_graduados'] = date('Y-m-d');


        $this->m_graduado->ingresoUsuario($data);
        echo '<div class="alert alert-success alert-dismissable">
                <i class="fa fa-check"></i>
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <b>Bien!</b> El graduado ha sido ingresado correctamente... 
              </div>';
    }

    function listarUsuarios() {
        $data = array();
        $where = array('estado_graduados' => 'G');
        $fetch_data = $this->m_graduado->crearTabla($where);
        foreach ($fetch_data as $row) {
            $sub_array = array();
            $sub_array[] = $row->nom1_graduados;
            $sub_array[] = $row->apep_graduados;
            $sub_array[] = $row->correo2_graduados;
            $sub_array[] = $row->telefm_graduados;
            $sub_array[] = '<div class="btn-group">
                                <button type="button" name="editarGraduado" id="' . $row->cod_graduados . '" class="btn btn-default"><i class="fa fa fa-edit"></i></button>
                                <button type="button" name="borrarGraduado" id="' . $row->cod_graduados . '" class="btn btn-default"><i class="fa fa-close"></i></button>
                            </div>';
            $data[] = $sub_array;
        }
        $output = array(
            "draw" => intval($_POST["draw"]),
            "recordsTotal" => $this->m_graduado->obtenerTodosDatos($where),
            "recordsFiltered" => $this->m_graduado->obtenerDatosFiltrados($where),
            "data" => $data
        );
        echo json_encode($output);
    }

    function obtenerUsuarioEditable() {
        $output = array();
        $data = $this->m_graduado->obtenerUsuarioEditable($_POST['cod_graduados']);
        foreach ($data as $row) {
            $output['nom1_graduados'] = $row->nom1_graduados;
            $output['nom2_graduados'] = $row->nom2_graduados;
            $output['apep_graduados'] = $row->apep_graduados;
            $output['apem_graduados'] = $row->apem_graduados;
            $output['correo1_graduados'] = $row->correo1_graduados;
            $output['telefm_graduados'] = $row->telefm_graduados;
            $output['teleff_graduados'] = $row->teleff_graduados;
            $output['ced_graduados'] = $row->ced_graduados;
        }
        echo json_encode($output);
    }

    function editarUsuario() {
        $updated_data = array(
            'nom1_graduados' => $this->input->post('nom1_graduados'),
            'nom2_graduados' => $this->input->post('nom2_graduados'),
            'apep_graduados' => $this->input->post('apep_graduados'),
            'apem_graduados' => $this->input->post('apem_graduados'),
            'correo1_graduados' => $this->input->post('correo1_graduados'),
            'telefm_graduados' => $this->input->post('telefm_graduados'),
            'teleff_graduados' => $this->input->post('teleff_graduados'),
            'ced_graduados' => $this->input->post('ced_graduados'),
        );

        $this->m_graduado->editarUsuario($this->input->post("cod_graduados"), $updated_data);
        echo '<div class="alert alert-success alert-dismissable">
                <i class="fa fa-check"></i>
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <b>Bien!</b> El graduado ha sido editado correctamente... 
              </div>';
    }

    function eliminarUsuario() {

        $updated_data = array(
            'estado_graduados' => 'E'
        );

        $this->m_graduado->eliminarUsuario($_POST["cod_graduados"], $updated_data);
        echo '<div class="alert alert-success alert-dismissable">
                <i class="fa fa-check"></i>
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <b>Bien!</b> El graduado ha sido eliminado correctamente... 
              </div>';
    }

    function obtenerDatosUsuario() {
        $output = array();
        $data = $this->m_graduado->obtenerDatosUsuario();
        $output[0] = "Seleccione un expositor";
        foreach ($data as $row) {
            $output[$row->cod_graduados] = $row->nom1_graduados . " " . $row->apep_graduados;
        }
        echo json_encode($output);
    }

}
