<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class C_login extends CI_Controller {

    public function _construct() {
        parent::__construct();
    }

    public function index() {

        $this->load->view('v_login');
        $this->iniciarSesion();
    }

    /**
     * Instancia la sesión, con el usuario, nombre y estado
     * @param $usuario se obtendrá su informacion para instanciar la session
     * @return true si se a instanciado correctamente la sesion
     */
    public function instanciarSesion($usuario) {
        $sess = array(
            'nom_admin' => $usuario->nom_admin,
            'ape_admin' => $usuario->ape_admin,
            'cod_admin' => $usuario->cod_admin,
            'adm_estatus' => true
        );
        $this->session->set_userdata($sess);
        return $this->session->userdata('adm_estatus');
    }

    /**
     * Crea la session con los tados traidos de la vista
     */
    public function iniciarSesion() {
        if (isset($_POST['password'])) {
            $this->load->model('m_login');
            $usuario = $this->m_login->login($_POST['user'], md5($_POST['password']));
            //    $this->load->library('Session');

            if (!empty($usuario) && $this->instanciarSesion($usuario)) {
                //if ($this->instanciarSesion($usuario)) {
                    redirect('c_general');
                    //redirect('c_administrador');
                    //header("location:" . base_url());
                /*} else {
                    redirect('c_login');
                }*/
            } else {
                redirect('c_login');
            }
        }
    }
}
