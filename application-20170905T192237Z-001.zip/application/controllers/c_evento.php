<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class C_evento extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('m_evento');
        $this->load->model('m_asistencia');
        $this->load->model('m_graduado');
    }

    function ingresoAsistencia($dataAsistencia) {
        $dataAsistidos = array();
        $dataAsistidos['cod_graduados'] = $dataAsistencia['cod_graduados'];
        $dataAsistidos['cod_evento'] = $dataAsistencia['cod_evento'];
        $dataAsistidos['estado_asistencia'] = $dataAsistencia['estado_asistencia'];

        $this->m_asistencia->ingresoAsistencia($dataAsistidos);
    }

    function ingresoEvento() {
        $data = array();
        $dataAsistencia = array();
        $data['tema_evento'] = strtoupper($_POST['tema_evento']);
        $data['lugar_evento'] = strtoupper($_POST['lugar_evento']);
        $data['fecha_evento'] = $_POST['fecha_evento'];
        $data['hora_evento'] = $_POST['hora_evento'];
        $data['contenido_evento'] = $_POST['contenido_evento'];
        $data['estado_evento'] = "H";

        $dataAsistencia['cod_evento'] = $this->m_evento->ingresoEvento($data);
        $dataAsistencia['cod_graduados'] = $_POST['cod_graduados'];
        $dataAsistencia['estado_asistencia'] = "X";
        //$cod_evento = $this->m_evento->ingresoEvento($data);

        $this->ingresoAsistencia($dataAsistencia);

        echo '<div class="alert alert-success alert-dismissable" id="cc">
                <i class="fa fa-check"></i>
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <b>Bien!</b> El evento ha sido ingresado correctamente... 
              </div>';
    }

    function listarEventos() {
        $data = array();
        $where = array('estado_evento' => 'H');
        //$where['estado_evento'] = "H";

        $fetch_data = $this->m_evento->crearTabla($where);
        foreach ($fetch_data as $row) {
            $sub_array = array();
            $sub_array[] = $row->tema_evento;
            $sub_array[] = $row->lugar_evento;
            $sub_array[] = $row->fecha_evento;
            $sub_array[] = $row->hora_evento;
            $sub_array[] = '<div class="btn-group">
                                <button type="button" name="editarEvento" id="' . $row->cod_evento . '" class="btn btn-default" data-toggle="tooltip" data-placement="bottom" title="Editar Evento"><i class="fa fa fa-edit"></i></button>                                
                                <button type="button" name="agregarAsistentesUsuarios" id="' . $row->cod_evento . '" class="btn btn-default"><i class="fa fa-user-plus" data-toggle="tooltip" data-placement="bottom" title="Agregar Asistentes"></i></button>
                                <button type="button" name="listarAsistentes" id="' . $row->cod_evento . '" class="btn btn-default"><i class="fa fa-list-ol" data-toggle="tooltip" data-placement="bottom" title="Listar Asistentes"></i></button>
                            </div>';
            $data[] = $sub_array;
        }
        $output = array(
            "draw" => intval($_POST["draw"]),
            "recordsTotal" => $this->m_evento->obtenerTodosDatos($where),
            "recordsFiltered" => $this->m_evento->obtenerDatosFiltrados($where),
            "data" => $data
        );
        echo json_encode($output);
    }

    function obtenerEventoEditable() {
        $output = array();
        $data = $this->m_evento->obtenerEventoEditable($_POST['cod_evento']);
        foreach ($data as $row) {
            $output['tema_evento'] = $row->tema_evento;
            $output['lugar_evento'] = $row->lugar_evento;
            $output['fecha_evento'] = $row->fecha_evento;
            $output['hora_evento'] = $row->hora_evento;
        }
        echo json_encode($output);
    }

    function listarEventoSingle() {
        $data = array();
        $where = array('estado_evento' => 'H', 'cod_evento' => $_POST['cod_evento']);

        $fetch_data = $this->m_evento->crearTabla($where);
        foreach ($fetch_data as $row) {
            $sub_array = array();
            $sub_array[] = $row->tema_evento;
            $sub_array[] = $row->lugar_evento;
            $sub_array[] = $row->fecha_evento;
            $sub_array[] = $row->hora_evento;
            $sub_array[] = '<div class="btn-group">
                                <button type="button" name="borrarEvento" id="' . $row->cod_evento . '" class="btn btn-default"><i class="fa fa-close" data-toggle="tooltip" data-placement="bottom" title="Terminar Evento"></i></button>
                            </div>';
            $data[] = $sub_array;
        }
        $output = array(
            "draw" => intval($_POST["draw"]),
            "recordsTotal" => $this->m_evento->obtenerTodosDatos($where),
            "recordsFiltered" => $this->m_evento->obtenerDatosFiltrados($where),
            "data" => $data
        );
        echo json_encode($output);
    }

    function editarEvento() {
        $updated_data = array(
            'tema_evento' => $this->input->post('tema_evento'),
            'lugar_evento' => $this->input->post('lugar_evento'),
            'fecha_evento' => $this->input->post('fecha_evento'),
            'hora_evento' => $this->input->post('hora_evento'),
        );

        $this->m_evento->editarEvento($this->input->post('cod_evento'), $updated_data);
        echo '<div class="alert alert-success alert-dismissable">
                <i class="fa fa-check"></i>
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <b>Bien!</b> El evento ha sido editado correctamente... 
              </div>';
    }

    function eliminarEvento() {

        $updated_data = array(
            'estado_evento' => 'E'
        );

        $this->m_evento->eliminarEvento($_POST['cod_evento'], $updated_data);
        echo '<div class="alert alert-success alert-dismissable">
                <i class="fa fa-check"></i>
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <b>Bien!</b> El evento ha sido terminado correctamente... 
              </div>';
    }

    function ingresoAsistentes() {
        $data = array(
            'nom1_graduados' => $this->input->strtoupper(post('nom1_graduados')),
            'apep_graduados' => $this->input->strtoupper(post('apep_graduados')),
            'ced_graduados' => $this->input->strtoupper(post('ced_graduados')),
            'telefm_graduados' => $this->input->strtoupper(post('telefm_graduados')),
            'correo2_graduados' => $this->input->post('correo2_graduados'),
            'cod_admin' => $this->session->userdata('cod_admin'),
            'estado_graduados' => 'S'
        );

        $dataAsistencia['cod_evento'] = $this->input->post('cod_eventos');
        $dataAsistencia['cod_graduados'] = $this->m_graduado->ingresoUsuario($data);
        $dataAsistencia['estado_asistencia'] = "A";

        $this->ingresoAsistencia($dataAsistencia);

        echo '<div class="alert alert-success alert-dismissable">
                <i class="fa fa-check"></i>
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <b>Bien!</b> El asistente ha sido ingresado correctamente... 
              </div>';
    }

    function listarAsistentes() {
        $data = array();
        $where = array('estado_asistencia' => 'A', 'cod_evento' => $_POST['cod_evento']);

        $fetch_data = $this->m_asistencia->crearTabla($where);
        foreach ($fetch_data as $key) {
            $cod_graduados = $key->cod_graduados;
            $where2 = array('estado_graduados' => 'S', 'cod_graduados' => $key->cod_graduados);
            $fetch_data2 = $this->m_graduado->crearTabla($where2);
            foreach ($fetch_data2 as $row2) {
                $sub_array = array();
                $sub_array[] = $row2->nom1_graduados;
                $sub_array[] = $row2->apep_graduados;
                $sub_array[] = $row2->correo2_graduados;
                $sub_array[] = $row2->telefm_graduados;
                $sub_array[] = $row2->ced_graduados;
                $data[] = $sub_array;
            }
        }

        $output = array(
            "draw" => 1,
            "recordsTotal" => $this->m_asistencia->obtenerTodosDatos($where),
            "recordsFiltered" => $this->m_asistencia->obtenerDatosFiltrados($where),
            "data" => $data
        );
        echo json_encode($output);
    }

    function obtenerDatosEvento() {
        $output = array();
        $data = $this->m_evento->obtenerDatosEvento();
        $output[0] = "Seleccione un evento";
        foreach ($data as $row) {
            $output[$row->cod_evento] = $row->tema_evento;
        }
        echo json_encode($output);
    }

    function crearContenidoMail($cod_evento) {

        $data = $this->m_evento->obtenerEventoEditable($cod_evento);
        foreach ($data as $row) {
            $output['tema_evento'] = $row->tema_evento;
            $output['lugar_evento'] = $row->lugar_evento;
            $output['fecha_evento'] = $row->fecha_evento;
            $output['hora_evento'] = $row->hora_evento;
            $output['contenido_evento'] = $row->contenido_evento;
        }

        $mail = array();
        $mail['contenido_evento'] = "<p><b>Información general</b></p>"
                . "<p><b>Tema:</b> " . $output['tema_evento'] . "</p>"
                . "<p><b>Lugar:</b> " . $output['lugar_evento'] . "</p>"
                . "<p><b>Hora:</b> " . $output['hora_evento'] . "</p>"
                . $output['contenido_evento'];
        return $mail;
    }

    function obtenerCorreos($where) {
        $correos = "";
        $graduado = $this->m_graduado->crearTabla($where);
        foreach ($graduado as $row) {
            $correos = $correos . $row->correo2_graduados . ",";
        }
        return substr($correos, 0, strlen($correos) - 1);
    }

    function sendMailGmail($where, $cod_evento) {
        $contenido = $this->crearContenidoMail($cod_evento);
        $correos = $this->obtenerCorreos($where);
        
        //return json_encode($correos);
        

        //cargamos la libreria email de ci
        $this->load->library("email");

        //configuracion para gmail
        $configGmail = array(
            'protocol' => 'smtp',
            'smtp_host' => 'ssl://smtp.gmail.com',
            //'smtp_host' => 'ssl://smtp.googlemail.com',
            'smtp_port' => 465,
            //'smtp_port' => 587,
            'smtp_user' => 'seguimiento.graduados.puce@gmail.com',
            'smtp_pass' => 'seguimiento.graduados.puce.2017',
            'mailtype' => 'html',
            'charset' => 'utf-8',
            'newline' => "\r\n"
        );

        //cargamos la configuración para enviar con gmail
        $this->email->initialize($configGmail);

        $this->email->from('Andres');
        $this->email->to($correos);
        $this->email->subject("Evento");
        $this->email->message($contenido['contenido_evento']);
        //$this->email->send();

        if ($this->email->send()) {
            return "se envió";
        } else {
            return "no se envió";
        }
    }

    function editarContenidoEvento() {
        $updated_data = array(
            'contenido_evento' => $this->input->post('contenido_evento'),
        );

        $this->m_evento->editarEvento($this->input->post('cod_eventos'), $updated_data);
        /*echo '<div class="alert alert-success alert-dismissable">
          <i class="fa fa-check"></i>
          <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
          <b>Bien!</b> El evento ha sido editado correctamente...
          </div>';*/
        if ($this->input->post('tipo') == "grupal") {
            $where = array('cod_cohorte' => $this->input->post('cod_cohorte'), 'cod_programa' => $this->input->post('cod_programa'));
            //echo json_encode($where);
        } else {
            $where = array('cod_graduados' => $this->input->post('cod_graduado'));
            //echo json_encode($where);
        }
        
        //echo $this->input->post('cod_eventos');
        //echo json_encode($where);

        echo $this->sendMailGmail($where, $this->input->post('cod_eventos'));
    }

}
