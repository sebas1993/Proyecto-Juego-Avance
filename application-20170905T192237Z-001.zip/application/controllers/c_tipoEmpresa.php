<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class C_tipoEmpresa extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('m_tipoEmpresa');
    }

    function obtenerDatosTipoEmpresa() {
        $output = array();
        $data = $this->m_tipoEmpresa->obtenerDatosTipoEmpresa();
        $output[0]="Seleccione el tipo de empresa";
        foreach ($data as $row) {
            $output[$row->cod_tipo] = $row->nom_tipo;
        }
        echo json_encode($output);
    }

}