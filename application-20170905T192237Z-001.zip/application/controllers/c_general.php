<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class C_general extends CI_Controller {

    public function __construct() {
        parent::__construct();
        //$this->load->model('m_administrador');
    }

    public function index() {
        $sess = $this->session->userdata('adm_estatus');

        if ($sess) {
            $this->load->view('v_administrador', $this->obtenerDatos());
        } else {
            header("location:" . base_url());
        }
    }

    /**
     * Se obtiene los datos de  la sesion para ser utilizados en la vista
     * @return $data
     */
    function obtenerDatos() {
        $data = array();
        $data['nom_admin'] = $this->session->userdata('nom_admin');
        $data['ape_admin'] = $this->session->userdata('ape_admin');
        return $data;
    }

}
