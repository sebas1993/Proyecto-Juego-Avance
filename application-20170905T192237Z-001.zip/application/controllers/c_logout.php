<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class C_logout extends CI_Controller {

    public function _construct() {
        parent::__construct();
    }

    public function index() {
        $cek = $this->session->userdata('nom_admin');
        if (empty($cek)) {
            //header("location:" . base_url());
            //redirect('c_administrador');
            redirect('c_general');
        } else {
            $this->session->sess_destroy();
            header("location:" . base_url());
        }
    }

}
