<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class C_cohorte extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('m_cohorte');
    }

    function obtenerDatosCohorte() {
        $output = array();
        $data = $this->m_cohorte->obtenerDatosCohorte();
        $output[0] = "Seleccione una cohorte";
        foreach ($data as $row) {
            $output[$row->cod_cohorte] = $row->nom_cohorte;
        }
        echo json_encode($output);
    }

    function ingresoCohorte() {
        $data = array();
        $num_cohorte = strtoupper($_POST['num_cohorte']);
        $anio_cohorte = strtoupper($_POST['anio_cohorte']);

        $data['num_cohorte'] = $num_cohorte;
        $data['anio_cohorte'] = $anio_cohorte;
        $data['nom_cohorte'] = $anio_cohorte . "-" . "0" . $num_cohorte;
        $data['estado_cohorte'] = "H";


        $this->m_cohorte->ingresoCohorte($data);
        echo '<div class="alert alert-success alert-dismissable">
                <i class="fa fa-check"></i>
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <b>Bien!</b> La cohorte ha sido ingresado correctamente... 
              </div>';
    }

    function listarCohortes() {
        $data = array();
        $where = array('estado_cohorte' => 'H');
        $fetch_data = $this->m_cohorte->crearTabla($where);
        foreach ($fetch_data as $row) {
            $sub_array = array();
            $sub_array[] = $row->nom_cohorte;
            $sub_array[] = $row->num_cohorte;
            $sub_array[] = $row->anio_cohorte;
            $sub_array[] = '<div class="btn-group">
                                <button type="button" name="editarCohorte" id="' . $row->cod_cohorte . '" class="btn btn-default"><i class="fa fa fa-edit"></i></button>
                                <button type="button" name="borrarCohorte" id="' . $row->cod_cohorte . '" class="btn btn-default"><i class="fa fa-close"></i></button>
                            </div>';
            $data[] = $sub_array;
        }
        $output = array(
            "draw" => intval($_POST["draw"]),
            "recordsTotal" => $this->m_cohorte->obtenerTodosDatos($where),
            "recordsFiltered" => $this->m_cohorte->obtenerDatosFiltrados($where),
            "data" => $data
        );
        echo json_encode($output);
    }

    function obtenerCohorteEditable() {
        $output = array();
        $data = $this->m_cohorte->obtenerCohorteEditable($_POST['cod_cohorte']);
        foreach ($data as $row) {
            $output['num_cohorte'] = $row->num_cohorte;
            $output['anio_cohorte'] = $row->anio_cohorte;
            //$output['nom_cohorte'] = $row->nom_cohorte;
        }
        echo json_encode($output);
    }

    function editarCohorte() {
        $num_cohorte = $this->input->post('num_cohorte');
        $anio_cohorte = $this->input->post('anio_cohorte');

        $updated_data = array(
            'num_cohorte' => $num_cohorte,
            'anio_cohorte' => $anio_cohorte,
            'nom_cohorte' => $anio_cohorte . "-" . "0" . $num_cohorte,
        );

        $this->m_cohorte->editarCohorte($this->input->post("cod_cohorte"), $updated_data);
        echo '<div class="alert alert-success alert-dismissable">
                <i class="fa fa-check"></i>
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <b>Bien!</b> La cohorte ha sido editado correctamente... 
              </div>';
    }

    function eliminarCohorte() {

        $updated_data = array(
            'estado_cohorte' => 'E'
        );

        $this->m_cohorte->eliminarCohorte($_POST["cod_cohorte"], $updated_data);
        echo '<div class="alert alert-success alert-dismissable">
                <i class="fa fa-check"></i>
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <b>Bien!</b> La cohorte ha sido eliminado correctamente... 
              </div>';
    }

}
